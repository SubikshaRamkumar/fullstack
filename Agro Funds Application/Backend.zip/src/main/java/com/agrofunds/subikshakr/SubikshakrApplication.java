package com.agrofunds.subikshakr;

// import org.springframework.boot.CommandLineRunner;
// import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// import com.agrofunds.subikshakr.dto.request.RegisterRequest;
// import com.agrofunds.subikshakr.service.AuthenticationService;

@SpringBootApplication
public class SubikshakrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubikshakrApplication.class, args);
	}

	// @Bean
	// public CommandLineRunner commandLineRunner(AuthenticationService authenticationService) {
	// 	return args -> {
	// 		var admin = RegisterRequest.builder()
	// 				.name("Admin")
	// 				.email("stringa").password("string")
	// 				.role("admin")
	// 				.build();
	// 		System.out.println("Admin Registration: " + authenticationService.register(admin).getMessage());

	// 		var user1 = RegisterRequest.builder()
	// 				.name("John")
	// 				.email("john@gmail.com").password("John@123")
	// 				.role("user")
	// 				.build();
	// 		System.out.println("User Registration: " + authenticationService.register(user1).getMessage());

	// 		var user2 = RegisterRequest.builder()
	// 				.name("Subi")
	// 				.email("stringu").password("string")
	// 				.role("user")
	// 				.build();
	// 		System.out.println("User Registration: " + authenticationService.register(user2).getMessage());
	// 	};


	// }

}
