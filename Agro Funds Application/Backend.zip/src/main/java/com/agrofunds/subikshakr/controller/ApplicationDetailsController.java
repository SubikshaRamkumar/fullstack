package com.agrofunds.subikshakr.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrofunds.subikshakr.dto.request.ApplicationDetailsRequest;
import com.agrofunds.subikshakr.dto.response.ApplicationDetailsResponse;
import com.agrofunds.subikshakr.dto.response.BasicResponse;
import com.agrofunds.subikshakr.service.ApplicationDetailsService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

import static com.agrofunds.subikshakr.utils.MyConstant.USER;
import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.EXPECTATION_FAILED;

import java.util.Collections;
import java.security.Principal;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping(USER)
@RequiredArgsConstructor
@Tag(name="ApplicationDetails")
@PreAuthorize("hasAnyRole('USER','ADMIN')")

public class ApplicationDetailsController {

    private final ApplicationDetailsService applicationDetailsService;
    
    @PostMapping("/addApplicationForm")
    @PreAuthorize("hasAnyAuthority('user:create','admin:create')")
    public ResponseEntity<?> postForm(@RequestBody ApplicationDetailsRequest adto,Principal principal) {
        BasicResponse<ApplicationDetailsResponse> response = new BasicResponse<>();
        try {
            ApplicationDetailsResponse formDetails = applicationDetailsService.addForm(adto,principal);
            response.setMessage("Form added Successfully");
            response.setData(Collections.singletonList(formDetails));
            return new ResponseEntity<>(response,ACCEPTED);
        } catch (Exception e) {
            response.setMessage("Failed to add form");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }
    
    @GetMapping("/getFormDetails/{formId}")
    @PreAuthorize("hasAnyAuthority('admin:read','user:read')")
    // @Operation(summary = "read all loan types By admin", description = "This API can read loan details (only admin)")
    public ResponseEntity<?> getDetail(@PathVariable("formId") Long formId ) {
        BasicResponse<ApplicationDetailsResponse> response = new BasicResponse<>();
        try {
            ApplicationDetailsResponse det = applicationDetailsService.getFormDetails(formId);
            response.setMessage("Form fetched Successfully by id");
            response.setData(Collections.singletonList(det)); 
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.setMessage("Failed to get!");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }

}
