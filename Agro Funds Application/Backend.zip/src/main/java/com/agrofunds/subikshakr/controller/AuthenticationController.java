package com.agrofunds.subikshakr.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrofunds.subikshakr.dto.request.LoginRequest;
import com.agrofunds.subikshakr.dto.request.RegisterRequest;
import com.agrofunds.subikshakr.dto.response.LoginResponse;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.service.AuthenticationService;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

import java.io.IOException;


import static com.agrofunds.subikshakr.utils.MyConstant.AUTH;
import static com.agrofunds.subikshakr.utils.MyConstant.REGISTER;
import static com.agrofunds.subikshakr.utils.MyConstant.LOGIN;
import static com.agrofunds.subikshakr.utils.MyConstant.REFRESR_TOKEN;
import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.EXPECTATION_FAILED;

@RestController
@RequestMapping(AUTH)
@RequiredArgsConstructor
@Tag(name="AUTH")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthenticationController {

    private final AuthenticationService authenticationService;
    
    @PostMapping(REGISTER)
    public ResponseEntity<RegisterResponse> registerUser(@RequestBody RegisterRequest request) {
        
        RegisterResponse response = new RegisterResponse();
        try {
            response = authenticationService.register(request);
            return new ResponseEntity<>(response,ACCEPTED);
        } catch (Exception e) {
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }

    @PostMapping(LOGIN)
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest request) {

        LoginResponse response = new LoginResponse();
        try {
            response = authenticationService.login(request);
            return new ResponseEntity<>(response,HttpStatus.OK);
            
        } catch (Exception e) {
            response.setMessage("Login failed!");
            response.setAccessToken(""); 
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }

    @PostMapping(REFRESR_TOKEN)   //Refresh tokens solve this problem by allowing the system to issue new access tokens without requiring the user to manually re-authenticate.
    public void refreshToken(
            HttpServletRequest request,
            HttpServletResponse response) throws IOException {
                authenticationService.refreshToken(request, response);
    }
    

}
