package com.agrofunds.subikshakr.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrofunds.subikshakr.dto.common.LoanTypesDto;
import com.agrofunds.subikshakr.dto.response.BasicResponse;
import com.agrofunds.subikshakr.service.LoanTypesService;

import static com.agrofunds.subikshakr.utils.MyConstant.USER;

import java.util.Collections;
import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.EXPECTATION_FAILED;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping(USER)
@RequiredArgsConstructor
@Tag(name="LoanTypes")
@PreAuthorize("hasRole('ADMIN')")
public class LoanTypesController {

    private final LoanTypesService lser;
    
    @PostMapping("/addLoanTypes")
    @PreAuthorize("hasAuthority('admin:create')")
    public ResponseEntity<?> postLoanTypes(@RequestBody LoanTypesDto ldto) {
        BasicResponse<LoanTypesDto> response = new BasicResponse<>();
        try {
            LoanTypesDto loanType = lser.addLoan(ldto);
            response.setMessage("loan added Successfully");
            response.setData(Collections.singletonList(loanType));
            return new ResponseEntity<>(response,ACCEPTED);
        } catch (Exception e) {
            response.setMessage("Failed to add loan");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }
    
    @GetMapping("/getAllLoanDetails")
    @Tag(name = "ADMIN")
    @PreAuthorize("hasAuthority('admin:read')")
    @Operation(summary = "read all loan types By admin", description = "This API can read loan details (only admin)")
    public ResponseEntity<?> getAllDetail() {
        BasicResponse<LoanTypesDto> response = new BasicResponse<>();
        try {
            List<LoanTypesDto> userDtos = lser.getAllLoanDetails();
            response.setMessage("User fetched Successfully");
            response.setData(userDtos); 
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.setMessage("Failed to get!");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }

}
