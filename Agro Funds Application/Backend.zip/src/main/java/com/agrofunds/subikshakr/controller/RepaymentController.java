package com.agrofunds.subikshakr.controller;
import static com.agrofunds.subikshakr.utils.MyConstant.USER;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping(USER)
@PreAuthorize("hasAnyRole('USER','ADMIN')")
@RequiredArgsConstructor
public class RepaymentController {

}
