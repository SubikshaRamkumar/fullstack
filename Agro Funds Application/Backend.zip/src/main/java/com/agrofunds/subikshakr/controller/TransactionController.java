package com.agrofunds.subikshakr.controller;

import static com.agrofunds.subikshakr.utils.MyConstant.USER;

import java.util.Collections;

import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.EXPECTATION_FAILED;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrofunds.subikshakr.dto.common.TransactionDto;
import com.agrofunds.subikshakr.dto.response.BasicResponse;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.service.TransactionService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping(USER)
@PreAuthorize("hasAnyRole('ADMIN')")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService tser;

    @PostMapping("/addTransaction")
    @PreAuthorize("hasAuthority('admin:create')")
    public ResponseEntity<?> postLoanTypes(@RequestBody TransactionDto tdto) {
        BasicResponse<TransactionDto> response = new BasicResponse<>();
        try {
            TransactionDto loanType = tser.addTransaction(tdto);
            response.setMessage("transaction added Successfully");
            response.setData(Collections.singletonList(loanType));
            return new ResponseEntity<>(response,ACCEPTED);
        } catch (Exception e) {
            response.setMessage("Failed to add transaction");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }

    @DeleteMapping("/delete")
    @Tag(name="ADMIN")
    @PreAuthorize("hasAuthority('admin:delete')")
    // @Operation(summary = "del user By id by admin not user", description = "This API can del details (only admin)")
    public ResponseEntity<?> delete() {
        RegisterResponse reponse = new RegisterResponse();
        try {
            reponse = tser.deleteTran();
            return new ResponseEntity<>(reponse, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

}
