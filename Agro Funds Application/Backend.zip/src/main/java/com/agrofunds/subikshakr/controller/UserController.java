package com.agrofunds.subikshakr.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agrofunds.subikshakr.dto.common.UserDto;
import com.agrofunds.subikshakr.dto.request.UserDtoRequest;
import com.agrofunds.subikshakr.dto.response.BasicResponse;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.dto.response.UserDtoResponse;
import com.agrofunds.subikshakr.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

import static com.agrofunds.subikshakr.utils.MyConstant.USER;
import static org.springframework.http.HttpStatus.EXPECTATION_FAILED;

import java.security.Principal;
import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;




@RestController
@RequestMapping(USER)
@PreAuthorize("hasAnyRole('USER','ADMIN')")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")
public class UserController {
    
    private final UserService userService;
    
    @GetMapping("/getDetail")
    @Tag(name = "USER")
    @Tag(name = "ADMIN")
    @Operation(summary = "Read user", description = "This API can get their details (both user and admin)")
    @PreAuthorize("hasAnyAuthority('user:read', 'admin:read')")
    public ResponseEntity<?> getDetail(Principal principal) {
        BasicResponse<UserDtoResponse> response = new BasicResponse<UserDtoResponse>();
        try {
            UserDtoResponse userDto = userService.getUserDetails(principal.getName());
            System.out.println(userDto);
            response.setMessage("User fetched Successfully");
            response.setData(Collections.singletonList(userDto));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.setMessage("Failed to get!");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }
    
    
    @PutMapping("/update")
    @Tag(name = "USER")
    @PreAuthorize("hasAuthority('user:update')")
    @Operation(summary = "Update user By user not admin", description = "This API can update their details (only user and not admin)")
    public ResponseEntity<?> updateDetailSelf(Principal principal,UserDtoRequest userDto) {
        BasicResponse<UserDtoResponse> response = new BasicResponse<UserDtoResponse>();
        try {
            UserDtoResponse UpdatedUserDto = userService.updateUserDetailsSelf(principal,userDto);
            response.setMessage("User fetched Successfully");
            response.setData(Collections.singletonList(UpdatedUserDto));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.setMessage("Failed to update!");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }
    

    @PutMapping("/update/{id}")
    @Tag(name = "ADMIN")
    @PreAuthorize("hasAnyAuthority('admin:update','user:update')")
    @Operation(summary = "Update user By admin and user", description = "This API can update details ")
    public ResponseEntity<?> updateDetail(@PathVariable("id") Long id,UserDtoRequest userDto) {
        BasicResponse<UserDtoResponse> response = new BasicResponse<UserDtoResponse>();
        try {
            UserDtoResponse UpdatedUserDto = userService.updateUserDetails(id,userDto);
            response.setMessage("User fetched Successfully");
            response.setData(Collections.singletonList(UpdatedUserDto));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.setMessage("Failed to update!");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }
    
    
    @GetMapping("/getAllDetail")
    @Tag(name = "ADMIN")
    @PreAuthorize("hasAuthority('admin:read')")
    @Operation(summary = "read all user By admin not user", description = "This API can read details (only admin)")
    public ResponseEntity<?> getAllDetail() {
        BasicResponse<UserDtoResponse> response = new BasicResponse<UserDtoResponse>();
        try {
            List<UserDtoResponse> userDtos = userService.getAllUserDetails();
            response.setMessage("User fetched Successfully");
            response.setData(userDtos); 
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.setMessage("Failed to get!");
            response.setData(Collections.emptyList());
            return new ResponseEntity<>(response,EXPECTATION_FAILED);
        }
    }

    @DeleteMapping("/delete/{userId}")
    @Tag(name="ADMIN")
    @PreAuthorize("hasAuthority('admin:delete')")
    @Operation(summary = "del user By id by admin not user", description = "This API can del details (only admin)")
    public ResponseEntity<?> deleteById(@PathVariable("userId") Long userId) {
        RegisterResponse reponse = new RegisterResponse();
        try {
            reponse = userService.deleteUser(userId);
            return new ResponseEntity<>(reponse, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }
   
}
