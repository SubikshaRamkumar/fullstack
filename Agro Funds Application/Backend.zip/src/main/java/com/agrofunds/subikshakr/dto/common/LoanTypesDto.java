package com.agrofunds.subikshakr.dto.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class LoanTypesDto {

    private Long loanId;

    private String loanTitle;

    private String scheme;

    private String description;

    private String objective;

    private String eligibility;

    private String loanAmount;

    private String repaymentPeriod;
    
    private String rateOfInterest;
    
    private String servicecharge;
}
