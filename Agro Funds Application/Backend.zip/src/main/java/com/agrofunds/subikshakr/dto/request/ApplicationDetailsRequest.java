package com.agrofunds.subikshakr.dto.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ApplicationDetailsRequest {

    private Long applicationId;

    private String applicationDate;

    private String desiredAmt;

    private String tenureMonths;

    private String applicationStatus;

    private String approvalDate;

    private Long loanId;

    // private Long userId;
}
