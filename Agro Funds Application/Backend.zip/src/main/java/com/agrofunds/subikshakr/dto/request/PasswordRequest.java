package com.agrofunds.subikshakr.dto.request;

public class PasswordRequest {

}
