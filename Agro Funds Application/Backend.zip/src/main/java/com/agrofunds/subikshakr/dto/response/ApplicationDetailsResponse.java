package com.agrofunds.subikshakr.dto.response;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ApplicationDetailsResponse {

    private Long applicationId;

    private String applicationDate;

    private String desiredAmt;

    private String tenureMonths;

    private String applicationStatus;

    private String approvalDate;

    private Long loanId;

    private Long userId;

    private Long transactionId;

    // private List<Long> repaymentId;
}
