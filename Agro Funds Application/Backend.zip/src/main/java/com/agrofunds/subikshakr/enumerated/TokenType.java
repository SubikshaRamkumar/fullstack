package com.agrofunds.subikshakr.enumerated;

public enum TokenType {
    BEARER
}
