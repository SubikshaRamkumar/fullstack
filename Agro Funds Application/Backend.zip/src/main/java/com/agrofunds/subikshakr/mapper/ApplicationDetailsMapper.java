package com.agrofunds.subikshakr.mapper;



import org.springframework.stereotype.Component;

import com.agrofunds.subikshakr.dto.request.ApplicationDetailsRequest;
import com.agrofunds.subikshakr.dto.response.ApplicationDetailsResponse;
import com.agrofunds.subikshakr.model.ApplicationDetails;
import com.agrofunds.subikshakr.model.LoanTypes;
import com.agrofunds.subikshakr.model.User;
import com.agrofunds.subikshakr.repository.LoanTypesRepository;
import com.agrofunds.subikshakr.repository.UserRepository;


@Component
public class ApplicationDetailsMapper {


    
    public static ApplicationDetails mapToApplicationDetails(ApplicationDetailsRequest adto,LoanTypesRepository lr,UserRepository ur,User user) {
        
        LoanTypes loanType = lr.findById(adto.getLoanId())
                .orElseThrow(() -> new RuntimeException("LoanType not found"));
        


        return ApplicationDetails.builder()
                .applicationId(adto.getApplicationId())
                .applicationDate(adto.getApplicationDate())
                .desiredAmt(adto.getDesiredAmt())
                .tenureMonths(adto.getTenureMonths())
                .applicationStatus(adto.getApplicationStatus())
                .approvalDate(adto.getApprovalDate())
                .loanType(loanType)
                .user(user)
                .transaction(null)
                // .repayments(null)
                .build();                   
    }

    public static ApplicationDetailsResponse mapToApplicationDetailsDto(ApplicationDetails applicationDetails) {

        // List<Long> repaymentIds = applicationDetails.getRepayments().stream()
        //     .map(Repayment -> Repayment.getRepaymentId())
        //     .collect(Collectors.toList());

        return ApplicationDetailsResponse.builder()
                .applicationId(applicationDetails.getApplicationId())
                .applicationDate(applicationDetails.getApplicationDate())
                .desiredAmt(applicationDetails.getDesiredAmt())
                .tenureMonths(applicationDetails.getTenureMonths())
                .applicationStatus(applicationDetails.getApplicationStatus())
                .approvalDate(applicationDetails.getApprovalDate())
                // Assuming loanId is needed in the DTO. Extracting the ID from the LoanTypes entity.
                .loanId(applicationDetails.getLoanType() != null ? applicationDetails.getLoanType().getLoanId() : null)
                .userId(applicationDetails.getUser() != null ? applicationDetails.getUser().getId() : null)
                .transactionId(applicationDetails.getTransaction()!=null? applicationDetails.getTransaction().getTransactionId():null)
                // .repaymentId(repaymentIds)
                .build();
    }




}
