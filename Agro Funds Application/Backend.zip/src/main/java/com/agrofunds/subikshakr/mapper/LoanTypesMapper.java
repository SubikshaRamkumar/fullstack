package com.agrofunds.subikshakr.mapper;


import org.springframework.stereotype.Component;

import com.agrofunds.subikshakr.dto.common.LoanTypesDto;

import com.agrofunds.subikshakr.model.LoanTypes;

@Component
public class LoanTypesMapper {

    public static LoanTypes mapToLoanTypes(LoanTypesDto ldto) {

        return LoanTypes.builder()
                .loanId(ldto.getLoanId())
                .loanTitle(ldto.getLoanTitle())
                .scheme(ldto.getScheme())
                .description(ldto.getDescription())
                .objective(ldto.getObjective())
                .eligibility(ldto.getEligibility())
                .loanAmount(ldto.getLoanAmount())
                .repaymentPeriod(ldto.getRepaymentPeriod())
                .rateOfInterest(ldto.getRateOfInterest())
                .servicecharge(ldto.getServicecharge())
                .build();   
    }

    public static LoanTypesDto mapToLoanTypesDto(LoanTypes loanType) {

        return LoanTypesDto.builder()
                .loanId(loanType.getLoanId())
                .loanTitle(loanType.getLoanTitle())
                .scheme(loanType.getScheme())
                .description(loanType.getDescription())
                .objective(loanType.getObjective())
                .eligibility(loanType.getEligibility())
                .loanAmount(loanType.getLoanAmount())
                .repaymentPeriod(loanType.getRepaymentPeriod())
                .rateOfInterest(loanType.getRateOfInterest())
                .servicecharge(loanType.getServicecharge())
                .build();
    }
}
