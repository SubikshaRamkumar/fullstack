package com.agrofunds.subikshakr.mapper;

public class RepaymentMapper {

}
