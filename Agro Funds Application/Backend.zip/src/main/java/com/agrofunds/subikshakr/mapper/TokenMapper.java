package com.agrofunds.subikshakr.mapper;

import com.agrofunds.subikshakr.dto.common.TokenDto;
import com.agrofunds.subikshakr.model.Token;


public class TokenMapper {
    public static TokenDto mapToTokenDto(Token t)
    {
        return new TokenDto(t.getId(),t.getToken(),t.getTokenType(),t.isRevoked(),t.isExpired(),t.getUser().getId());
    }
    // public static Token mapToToken(TokenDto td)
    // {
    //     return new User(userDto.getId(),userDto.getName(),userDto.getEmail(),userDto.getPassword(),userDto.getRole(),userDto.getAge(),userDto.getMobile_no(),userDto.getDateofBirth(),userDto.getGender(),userDto.getMaritalStatus(),userDto.getAddressLine1(),userDto.getAddressLine2(),userDto.getCity(),userDto.getState(),userDto.getCountry(),userDto.getNationality(),userDto.getPincode());
    // }
}
