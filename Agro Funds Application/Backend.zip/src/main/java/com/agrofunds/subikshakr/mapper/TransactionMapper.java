package com.agrofunds.subikshakr.mapper;

import org.springframework.stereotype.Component;

import com.agrofunds.subikshakr.dto.common.TransactionDto;
import com.agrofunds.subikshakr.model.ApplicationDetails;
import com.agrofunds.subikshakr.model.Transaction;
import com.agrofunds.subikshakr.repository.ApplicationDetailsRepository;

@Component
public class TransactionMapper {

    public static Transaction mapToTransaction(TransactionDto tdto,ApplicationDetailsRepository arepo) {
        ApplicationDetails applicationDetails = arepo.findById(tdto.getApplicationId())
                .orElseThrow(() -> new RuntimeException("Application not found"));


        return Transaction.builder()
                                .transactionId(tdto.getTransactionId())
                                .transactionAmount(tdto.getTransactionAmount())
                                .transactionDate(tdto.getTransactionDate())
                                .transactionStatus(tdto.getTransactionStatus())
                                .applicationDetail(applicationDetails)
                                .build();
    }

    public static TransactionDto mapToTransactionDto(Transaction transaction) {
        return TransactionDto.builder()
                .transactionId(transaction.getTransactionId())
                .transactionAmount(transaction.getTransactionAmount())
                .transactionDate(transaction.getTransactionDate())
                .transactionStatus(transaction.getTransactionStatus())
                // Extract ApplicationDetails ID if present
                .applicationId(transaction.getApplicationDetail() != null ? transaction.getApplicationDetail().getApplicationId() : null)
                .build();
    }

}
