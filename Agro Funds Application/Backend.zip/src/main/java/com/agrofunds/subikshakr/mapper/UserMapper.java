package com.agrofunds.subikshakr.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.agrofunds.subikshakr.dto.common.UserDto;
import com.agrofunds.subikshakr.dto.response.UserDtoResponse;
import com.agrofunds.subikshakr.model.ApplicationDetails;
import com.agrofunds.subikshakr.model.Token;
import com.agrofunds.subikshakr.model.User;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class UserMapper {

    public static UserDtoResponse mapToUserDto(User user)
    {
        List<Long> tokenIds = user.getTokens().stream()
                              .map(Token::getId)
                              .collect(Collectors.toList());
        List<Long> applicationIds = user.getApplications().stream()
                              .map(ApplicationDetails::getApplicationId)
                              .collect(Collectors.toList());
        return UserDtoResponse.builder()
                      .id(user.getId())
                      .name(user.getName())
                      .email(user.getEmail())
                      .password(user.getPassword()) // Consider excluding password for security reasons
                      .role(user.getRole())
                      .age(user.getAge())
                      .mobile_no(user.getMobile_no())
                      .dateofBirth(user.getDateofBirth())
                      .gender(user.getGender())
                      .maritalStatus(user.getMaritalStatus())
                      .addressLine1(user.getAddressLine1())
                      .addressLine2(user.getAddressLine2())
                      .city(user.getCity())
                      .state(user.getState())
                      .nationality(user.getNationality())
                      .country(user.getCountry())
                      .pincode(user.getPincode())
                      .tokenId(tokenIds)
                      .applicationId(applicationIds)
                      .build();
    }
    // public User mapToUser(UserDto userDto)
    // {
    //     User user = userRepository.findByEmail(userDto.getEmail())
    //                           .orElse(new User()); 
    //     return new User(user.getId(),user.getName(),user.getEmail(),user.getPassword(),user.getRole(),user.getAge(),user.getMobile_no(),user.getDateofBirth(),user.getGender(),user.getMaritalStatus(),user.getAddressLine1(),user.getAddressLine2(),user.getCity(),user.getState(),user.getCountry(),user.getNationality(),user.getPincode(),user.getTokens(),user.getApplications());
    // }
    
}
