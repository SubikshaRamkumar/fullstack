package com.agrofunds.subikshakr.model;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="application_details")
public class ApplicationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    private String applicationDate;

    private String desiredAmt;

    private String tenureMonths;

    private String applicationStatus;

    private String approvalDate;

    @ManyToOne
    @JoinColumn(name = "loanId", nullable = false,referencedColumnName = "loanId")
    private LoanTypes loanType;

    @ManyToOne(fetch = FetchType.LAZY)  //Indicates that the user associated with a token should be loaded lazily. That is, the user data is fetched from the database only when it's accessed for the first time.
    @JoinColumn(name = "userId",referencedColumnName = "id")
    public User user;

    @OneToOne(mappedBy = "applicationDetail", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Transaction transaction;

    // @OneToMany(mappedBy = "applicationDetail", cascade = CascadeType.ALL, orphanRemoval = true)
    // private List<Repayment> repayments ;

}
