package com.agrofunds.subikshakr.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="loan_Types")
public class LoanTypes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
    private Long loanId;

    private String loanTitle;

    private String scheme;

    private String description;

    private String objective;

    private String eligibility;

    private String loanAmount;

    private String repaymentPeriod;
    
    private String rateOfInterest;
    
    private String servicecharge;

    // @OneToMany(mappedBy = "loanType", cascade = CascadeType.ALL)
    // private List<ApplicationDetails> applicationDetails;

}
