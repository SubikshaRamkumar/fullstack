package com.agrofunds.subikshakr.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="repayment_details")
public class Repayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long repaymentId;

    private String repaymentDate;
    private String amountPaid;
    private String remainingBalance;
    private String total_amount;
    private String paid_months;
    private String due_months;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applicationId",referencedColumnName = "applicationId")
    private ApplicationDetails applicationDetail;

}
