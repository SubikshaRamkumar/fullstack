package com.agrofunds.subikshakr.model;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="transaction_details")
public class Transaction {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long transactionId;

    private String transactionAmount;

    private String transactionDate;

    private String transactionStatus;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applicationId")
    private ApplicationDetails applicationDetail;

}
