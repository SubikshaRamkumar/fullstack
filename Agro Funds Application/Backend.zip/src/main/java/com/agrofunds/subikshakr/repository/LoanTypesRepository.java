package com.agrofunds.subikshakr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.agrofunds.subikshakr.model.LoanTypes;

public interface LoanTypesRepository extends JpaRepository<LoanTypes,Long> {

}
