package com.agrofunds.subikshakr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.agrofunds.subikshakr.model.Repayment;

public interface RepayamentRepository extends JpaRepository<Repayment,Long> {

}
