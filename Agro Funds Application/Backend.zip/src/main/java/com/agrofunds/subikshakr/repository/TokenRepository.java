package com.agrofunds.subikshakr.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.agrofunds.subikshakr.model.Token;

public interface TokenRepository extends JpaRepository<Token,Long> {

    Optional<Token> findByToken(String token);

    @Query("SELECT t FROM Token t WHERE t.user.id = :userId")
    List<Token> findAllValidTokenByUser(@Param("userId") Long userId);
    
}
