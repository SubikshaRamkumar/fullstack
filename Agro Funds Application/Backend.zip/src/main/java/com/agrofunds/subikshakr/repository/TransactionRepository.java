package com.agrofunds.subikshakr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.agrofunds.subikshakr.model.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction,Long> {

}
