package com.agrofunds.subikshakr.service;


import java.security.Principal;

import com.agrofunds.subikshakr.dto.request.ApplicationDetailsRequest;
import com.agrofunds.subikshakr.dto.response.ApplicationDetailsResponse;

public interface ApplicationDetailsService {

    ApplicationDetailsResponse addForm(ApplicationDetailsRequest adto,Principal principal);

    ApplicationDetailsResponse getFormDetails(Long formId);

    
} 
