package com.agrofunds.subikshakr.service;

import com.agrofunds.subikshakr.dto.request.LoginRequest;
import com.agrofunds.subikshakr.dto.request.RegisterRequest;
import com.agrofunds.subikshakr.dto.response.LoginResponse;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;

import java.io.IOException;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface AuthenticationService {

    RegisterResponse register(RegisterRequest request);

    LoginResponse login(LoginRequest request);

    void refreshToken(HttpServletRequest request, HttpServletResponse response) throws IOException;

}
