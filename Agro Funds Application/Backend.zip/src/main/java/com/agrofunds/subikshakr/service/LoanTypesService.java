package com.agrofunds.subikshakr.service;

import java.util.List;

import com.agrofunds.subikshakr.dto.common.LoanTypesDto;


public interface LoanTypesService {

    LoanTypesDto addLoan(LoanTypesDto ldto);

    List<LoanTypesDto> getAllLoanDetails();

}
