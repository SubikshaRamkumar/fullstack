package com.agrofunds.subikshakr.service;

public interface RepaymentService {

}
