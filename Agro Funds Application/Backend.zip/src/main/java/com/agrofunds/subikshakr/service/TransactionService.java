package com.agrofunds.subikshakr.service;

import com.agrofunds.subikshakr.dto.common.TransactionDto;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;

public interface TransactionService {

    TransactionDto addTransaction(TransactionDto tdto);

    RegisterResponse deleteTran();

}
