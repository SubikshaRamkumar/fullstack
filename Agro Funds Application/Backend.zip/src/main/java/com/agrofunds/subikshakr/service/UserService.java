package com.agrofunds.subikshakr.service;

import java.security.Principal;
import java.util.List;

import com.agrofunds.subikshakr.dto.common.UserDto;
import com.agrofunds.subikshakr.dto.request.UserDtoRequest;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.dto.response.UserDtoResponse;

public interface UserService {

    UserDtoResponse getUserDetails(String email);

    List<UserDtoResponse> getAllUserDetails();

    UserDtoResponse updateUserDetails(Long id, UserDtoRequest userDto);

    RegisterResponse deleteUser(Long userId);

    UserDtoResponse updateUserDetailsSelf(Principal principal, UserDtoRequest userDto);

}
