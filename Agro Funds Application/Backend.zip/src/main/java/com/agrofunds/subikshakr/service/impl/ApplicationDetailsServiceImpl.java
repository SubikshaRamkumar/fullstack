package com.agrofunds.subikshakr.service.impl;

import java.security.Principal;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.agrofunds.subikshakr.dto.request.ApplicationDetailsRequest;
import com.agrofunds.subikshakr.dto.response.ApplicationDetailsResponse;
import com.agrofunds.subikshakr.exception.UserNotFoundException;
import com.agrofunds.subikshakr.mapper.ApplicationDetailsMapper;
import com.agrofunds.subikshakr.model.ApplicationDetails;
import com.agrofunds.subikshakr.model.User;
import com.agrofunds.subikshakr.repository.ApplicationDetailsRepository;
import com.agrofunds.subikshakr.repository.LoanTypesRepository;
import com.agrofunds.subikshakr.repository.UserRepository;
import com.agrofunds.subikshakr.service.ApplicationDetailsService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ApplicationDetailsServiceImpl implements ApplicationDetailsService {

    private final ApplicationDetailsRepository ar;
    private final LoanTypesRepository lr;
    private final UserRepository ur;
    @Override
    public ApplicationDetailsResponse addForm(ApplicationDetailsRequest adto,Principal principal) {
        
        User user = ur.findByEmail(principal.getName()).orElseThrow(()->new UserNotFoundException("User not found"));

        ApplicationDetails form = ApplicationDetailsMapper.mapToApplicationDetails(adto,lr,ur,user);
        ApplicationDetails savedForm = ar.save(form);
        return ApplicationDetailsMapper.mapToApplicationDetailsDto(savedForm);
    }
    @Override
    public ApplicationDetailsResponse getFormDetails(Long formId) {
        Optional<ApplicationDetails> opForm = ar.findById(formId);
        ApplicationDetails appForm = opForm.orElseThrow(() ->
        new UserNotFoundException("form not found with id: " + formId));
        return ApplicationDetailsMapper.mapToApplicationDetailsDto(appForm);
    }

}
