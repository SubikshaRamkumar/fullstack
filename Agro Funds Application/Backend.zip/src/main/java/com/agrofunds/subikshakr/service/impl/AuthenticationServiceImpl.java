package com.agrofunds.subikshakr.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.agrofunds.subikshakr.dto.request.LoginRequest;
import com.agrofunds.subikshakr.dto.request.RegisterRequest;
import com.agrofunds.subikshakr.dto.response.LoginResponse;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.enumerated.Role;
import com.agrofunds.subikshakr.model.Token;
import com.agrofunds.subikshakr.model.User;
import com.agrofunds.subikshakr.repository.TokenRepository;
import com.agrofunds.subikshakr.repository.UserRepository;
import com.agrofunds.subikshakr.service.AuthenticationService;
import com.agrofunds.subikshakr.utils.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import static com.agrofunds.subikshakr.enumerated.TokenType.BEARER;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;



import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {
    
    private final UserRepository userRepository;
    private final TokenRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;


    @Override
    public RegisterResponse register(RegisterRequest request) {
        var user = User.builder()
                        .name(request.getName())
                        .email(request.getEmail())
                        .password(passwordEncoder.encode(request.getPassword()))
                        .role(Role.valueOf(request.getRole().toUpperCase()))
                        .build();
        userRepository.save(user);
        return RegisterResponse.builder().message("User Registered Successfully").build();
    }

    @Override
    public LoginResponse login(LoginRequest request) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(),
                                                request.getPassword()));  
                                            
               
                var user = userRepository.findByEmail(request.getEmail()).orElseThrow();


                Map<String, Object> claims = new HashMap<>();
                claims.put("role", user.getRole().toString());  

                var accessToken = jwtUtil.generateToken(claims, user);

                revokeAllUserTokens(user);  //The revokeAllUserTokens(user) method is invoked to invalidate any existing tokens that have been issued to the user. This is a security measure to ensure that any previous tokens, potentially compromised, are no longer valid.

                saveUserToken(user, accessToken); //. This typically involves creating a new Token entity and persisting it.

                return LoginResponse.builder()
                                .message("Logged in successfully.")
                                .accessToken(accessToken)
                                .build();
    }

    private void revokeAllUserTokens(User user) {
        var validUserTokens = tokenRepository.findAllValidTokenByUser(user.getId());
        if (validUserTokens.isEmpty())
                return;
        validUserTokens.forEach(token -> {
                token.setExpired(true);
                token.setRevoked(true);
        });
        tokenRepository.saveAll(validUserTokens);
    }

    private void saveUserToken(User user, String accessToken) {
        var token = Token.builder()
                        .user(user)
                        .token(accessToken)
                        .tokenType(BEARER)
                        .expired(false)
                        .revoked(false)
                        .build();
        tokenRepository.save(token);
    
    }

    @Override
        public void refreshToken(HttpServletRequest request, HttpServletResponse response) throws IOException {
                final String authHeader = request.getHeader(AUTHORIZATION);   //This header is expected to contain the refresh token, prefixed with "Bearer ".
                final String refreshToken;
                final String userEmail;


                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                        return;
                }


                refreshToken = authHeader.substring(7);  //Assuming the header is correctly formatted, it extracts the actual token part by removing the "Bearer " prefix.
                userEmail = jwtUtil.extractUsername(refreshToken);  // It uses jwtUtil.extractUsername(refreshToken) to extract the username (in this case, an email) from the refresh token. This is based on the assumption that the refresh token contains the username as a claim.

                if (userEmail != null) {
                        var user = this.userRepository.findByEmail(userEmail).orElseThrow();
                        if (jwtUtil.isTokenValid(refreshToken, user)) {
                                var accessToken = jwtUtil.generateToken(user);
                                revokeAllUserTokens(user);
                                saveUserToken(user, accessToken);
                                var authResponse = LoginResponse.builder()
                                                .message("New access token generated successfully.")
                                                .accessToken(accessToken)
                                                .build();
                                new ObjectMapper().writeValue(response.getOutputStream(), authResponse);  //This response object is serialized to JSON and written to the HttpServletResponse output stream, effectively returning the new access token to the client.
                        }
                }
        }

}
