package com.agrofunds.subikshakr.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.agrofunds.subikshakr.dto.common.LoanTypesDto;

import com.agrofunds.subikshakr.mapper.LoanTypesMapper;
import com.agrofunds.subikshakr.model.LoanTypes;
import com.agrofunds.subikshakr.repository.LoanTypesRepository;
import com.agrofunds.subikshakr.service.LoanTypesService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoanTypesServiceImpl implements LoanTypesService{

    private final LoanTypesRepository lr;

    @Override
    public LoanTypesDto addLoan(LoanTypesDto ldto) {

        LoanTypes loan = LoanTypesMapper.mapToLoanTypes(ldto);
        LoanTypes savedLoan = lr.save(loan);
        return LoanTypesMapper.mapToLoanTypesDto(savedLoan);
        
    }

    @Override
    public List<LoanTypesDto> getAllLoanDetails() {
        List<LoanTypes> loanTypes = lr.findAll();
        List<LoanTypesDto> loanTypesDtos = new ArrayList<>();
        for (LoanTypes loanType : loanTypes) {
            LoanTypesDto loanTypesDto = LoanTypesMapper.mapToLoanTypesDto(loanType);
            loanTypesDtos.add(loanTypesDto);
        }
        return loanTypesDtos;
    }
}
