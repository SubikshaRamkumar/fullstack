package com.agrofunds.subikshakr.service.impl;

import com.agrofunds.subikshakr.service.RepaymentService;

public class RepaymentServiceImpl implements RepaymentService{

}
