package com.agrofunds.subikshakr.service.impl;

import org.springframework.stereotype.Service;

import com.agrofunds.subikshakr.dto.common.TransactionDto;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.mapper.TransactionMapper;
import com.agrofunds.subikshakr.model.Transaction;
import com.agrofunds.subikshakr.repository.ApplicationDetailsRepository;
import com.agrofunds.subikshakr.repository.TransactionRepository;
import com.agrofunds.subikshakr.service.TransactionService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService{

    private final TransactionRepository trepo;
    private final ApplicationDetailsRepository arepo;
    @Override
    public TransactionDto addTransaction(TransactionDto tdto) {
        Transaction tran = TransactionMapper.mapToTransaction(tdto,arepo);
        Transaction savedTran = trepo.save(tran);
        return TransactionMapper.mapToTransactionDto(savedTran);
    }
    @Override
    public RegisterResponse deleteTran() {
        trepo.deleteAll();
        return RegisterResponse.builder().message("Transaction Deleted Successfully").build();
    }

}
