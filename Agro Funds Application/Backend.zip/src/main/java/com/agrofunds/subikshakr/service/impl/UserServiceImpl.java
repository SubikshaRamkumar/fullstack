package com.agrofunds.subikshakr.service.impl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.agrofunds.subikshakr.dto.common.UserDto;
import com.agrofunds.subikshakr.dto.request.UserDtoRequest;
import com.agrofunds.subikshakr.dto.response.RegisterResponse;
import com.agrofunds.subikshakr.dto.response.UserDtoResponse;
import com.agrofunds.subikshakr.exception.UserNotFoundException;
import com.agrofunds.subikshakr.mapper.UserMapper;
import com.agrofunds.subikshakr.model.User;
import com.agrofunds.subikshakr.repository.UserRepository;
import com.agrofunds.subikshakr.service.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository ur;

    @Override
    public UserDtoResponse getUserDetails(String email) {
        Optional<User> optionalUser = ur.findByEmail(email);
        User user = optionalUser.orElseThrow(() ->
        new UserNotFoundException("User not found with email: " + email));
        return UserMapper.mapToUserDto(user);
    }

    @Override
    public List<UserDtoResponse> getAllUserDetails() {
        List<User> users = ur.findAll();
        List<UserDtoResponse> userDtos = new ArrayList<>();
        for (User user : users) {
            UserDtoResponse userDto = UserMapper.mapToUserDto(user); // Assuming you have a method like this in UserMapper
            userDtos.add(userDto);
        }
        return userDtos;
    }

    @Override
    public UserDtoResponse updateUserDetails(Long id, UserDtoRequest userDto) {
        Optional<User> optionalUser = ur.findById(id);
        User existingUser = optionalUser.orElseThrow(() ->
        new UserNotFoundException("User not found"));

        existingUser.setName(userDto.getName());
        existingUser.setEmail(userDto.getEmail());
        existingUser.setAge(userDto.getAge());
        existingUser.setMobile_no(userDto.getMobile_no());
        existingUser.setDateofBirth(userDto.getDateofBirth());
        existingUser.setGender(userDto.getGender());
        existingUser.setMaritalStatus(userDto.getMaritalStatus());
        existingUser.setAddressLine1(userDto.getAddressLine1());
        existingUser.setAddressLine2(userDto.getAddressLine2());
        existingUser.setCity(userDto.getCity());
        existingUser.setState(userDto.getState());
        existingUser.setNationality(userDto.getNationality());
        existingUser.setCountry(userDto.getCountry());
        existingUser.setPincode(userDto.getPincode());
        User updatedUser = ur.save(existingUser);

        return UserMapper.mapToUserDto(updatedUser);

    }

    @Override
    public RegisterResponse deleteUser(Long userId) {
        ur.deleteById(userId);
        return RegisterResponse.builder().message("User Deleted Successfully").build();
    }

    @Override
    public UserDtoResponse updateUserDetailsSelf(Principal principal, UserDtoRequest userDto) {
        Optional<User> optionalUser = ur.findByEmail(principal.getName());
        User existingUser = optionalUser.orElseThrow(() ->
        new UserNotFoundException("User not found"));

        existingUser.setName(userDto.getName());
        existingUser.setEmail(userDto.getEmail());
        existingUser.setAge(userDto.getAge());
        existingUser.setMobile_no(userDto.getMobile_no());
        existingUser.setDateofBirth(userDto.getDateofBirth());
        existingUser.setGender(userDto.getGender());
        existingUser.setMaritalStatus(userDto.getMaritalStatus());
        existingUser.setAddressLine1(userDto.getAddressLine1());
        existingUser.setAddressLine2(userDto.getAddressLine2());
        existingUser.setCity(userDto.getCity());
        existingUser.setState(userDto.getState());
        existingUser.setNationality(userDto.getNationality());
        existingUser.setCountry(userDto.getCountry());
        existingUser.setPincode(userDto.getPincode());
        User updatedUser = ur.save(existingUser);

        return UserMapper.mapToUserDto(updatedUser);
    }

}
