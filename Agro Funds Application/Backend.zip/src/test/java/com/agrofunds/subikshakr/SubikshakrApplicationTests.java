package com.agrofunds.subikshakr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubikshakrApplicationTests {

	@Test
	void contextLoads() {
	}

}
