import { useState } from "react";
import "../../assets/css/calculator1.css";
// import "../../assets/css/calculator.css";
import { Pie } from "react-chartjs-2";
import { ArcElement, Chart, Tooltip, Legend } from "chart.js";
Chart.register(ArcElement, Tooltip, Legend);

const Calculator = () => {
  const [amt, setAmt] = useState(10000);
  const [rate, setRate] = useState(7.5);
  const [tenure, setTenure] = useState(120);
  const [loanEMI, setLoanEMI] = useState(119);
  const [totalIntPayable, setTotalIntPayable] = useState(4244);
  const [totalAmt, setTotalAmt] = useState(14244);

  const chartData = {
    labels: ["Total Interest", "Principal Loan Amount"],
    datasets: [
      {
        data: [parseFloat(totalIntPayable), parseFloat(amt)],
        backgroundColor: ["rgba(85,52,62,0.6)", "#55343e"],
        // backgroundColor: ["rgba(85,52,62,0.8)", "rgba(19,33,61,0.9)"],
        borderWidth: 0,
      },
    ],
  };

  const chartOptions = {
    maintainAspectRatio: false,
    responsive: true,
    plugins: {
      tooltip: {
        enabled: true, // Explicitly enable tooltips
      },
    },
  };

  const calcEMI = (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    let loanAmt = parseFloat(amt);
    let intRate = parseFloat(rate);
    let loanTenure = parseFloat(tenure);
    let interest = intRate / 12 / 100;

    if (!isNaN(loanAmt) && !isNaN(intRate) && !isNaN(loanTenure)) {
      let emi =
        loanAmt *
        interest *
        (Math.pow(1 + interest, loanTenure) /
          (Math.pow(1 + interest, loanTenure) - 1));
      let totalAmt = Math.round(emi * loanTenure);
      let totalInterestPayable = Math.round(totalAmt - loanAmt);

      setLoanEMI(Math.round(emi));
      setTotalAmt(totalAmt);
      setTotalIntPayable(totalInterestPayable);

      return { totalInterestPayable, loanAmt };
    }
    return { totalInterestPayable: 0, loanAmt: 0 };
  };

  return (
    <div className="loan_calc">
      <div className="top">
        <h2>Loan Calculator</h2>
        <form onSubmit={calcEMI}>
          <div className="group">
            <div className="title">Amount</div>
            <input
              type="number"
              value={amt}
              className="loan_amount"
              onChange={(e) => setAmt(e.target.value)}
            />
          </div>
          <div className="group">
            <div className="title">Interest Rate</div>
            <input
              type="number"
              value={rate}
              className="interest_rate"
              onChange={(e) => setRate(e.target.value)}
            />
          </div>
          <div className="group">
            <div className="title">Tenure(in month)</div>
            <input
              type="number"
              value={tenure}
              className="tenure_month"
              onChange={(e) => setTenure(e.target.value)}
            />
          </div>
          <div className="calc_butt">
            <button className="calc_button">
              Calculate
            </button>
          </div>
        </form>
      </div>
      <div className="result">
        <div className="left">
          <div className="loan_emi">
            <h4>Loan EMI</h4>
            <div className="value">{loanEMI}</div>
          </div>
          <div className="total_int">
            <h4>Total Interest Payable</h4>
            <div className="value">{totalIntPayable}</div>
          </div>
          <div className="total_amt">
            <h4>Total Amount</h4>
            <div className="value">{totalAmt}</div>
          </div>
        </div>
        <div className="right">
          <div
            style={{ width: "250px", height: "250px", marginBottom: "30px" }}
          >
            <Pie data={chartData} options={chartOptions} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calculator;
