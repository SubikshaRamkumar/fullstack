import PropTypes from "prop-types";
import "../../assets/css/emiOverview.css";
import * as React from "react";
import Box from "@mui/material/Box";
import LinearProgress from "@mui/material/LinearProgress";

const EmiDetails = ({ listData }) => {
  const [progress, setProgress] = React.useState(0);
  const [paidEmis, setPaidEmis] = React.useState(9);
  const [totalEmis, setTotalEmis] = React.useState(56);

  React.useEffect(() => {
    const paidPercentage = Math.round((paidEmis / totalEmis) * 100);
    if (paidEmis === 0) {
      setProgress(0);
    } else {
      setProgress(paidPercentage);
    }
  }, [paidEmis, totalEmis]);

  return (
    <div className="Loan_overview" style={{ paddingTop: "30px",paddingBottom:"20px" }}>
      <h3 style={{textAlign:"center"}}>Loan Overview</h3>
      <div className="whole_emi_flex">
        {listData.map((item, index) => {
          return (
            <div className="emi_overview_box" key={index}>
              <span style={{ fontSize: "12px" }}>Loan Id : {item.loanId}</span>
              <h3>{item.loanType}</h3>
              <div className="emi_group">
                <div className="emi_group_head">
                  <div className="tit">Activated Loan EMI</div>
                  <div className="emi_content">
                    <div className="emi_content1">
                      <p>
                        <span className="week">52</span>
                        <span className="week2"> Weeks</span>
                      </p>
                      <div className="head">TOTAL EMI</div>
                    </div>
                    <div className="emi_content1">
                      <p>1000000</p>
                      <div className="head">AMOUNT</div>
                    </div>
                  </div>
                </div>
                <div className="emi_group_head">
                  <div className="tit">EMI Status</div>
                  <div className="emi_content">
                    <div className="emi_content1">
                      <p>
                        <span className="paid">39</span>
                      </p>
                      <div className="head">PAID</div>
                    </div>
                    <div className="emi_content1">
                      <p>
                        <span className="due">52</span>
                      </p>
                      <div className="head">DUE</div>
                    </div>
                    <div className="emi_content1">
                      <p>13-15-2024</p>
                      <div className="head">NEXT EMI DATE</div>
                    </div>
                  </div>
                </div>
                <div className="emi_group_head head3">
                  <div className="tit">EMI Status</div>
                  <div className="emi_content">
                    <Box sx={{ width: "100%" }}>
                      <LinearProgress variant="determinate" value={progress} />
                      <div className="percent">{progress}%</div>
                    </Box>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

EmiDetails.propTypes = {
  listData: PropTypes.arrayOf(
    PropTypes.shape({
      loanId: PropTypes.number.isRequired,
      loanType: PropTypes.string.isRequired,
      date: PropTypes.string.isRequired,
      amount: PropTypes.string.isRequired,
      status: PropTypes.string.isRequired,
    })
  ).isRequired,
};

export default EmiDetails;
