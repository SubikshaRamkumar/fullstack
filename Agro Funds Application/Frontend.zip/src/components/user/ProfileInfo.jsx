import "../../assets/css/profileInfo.css";
import { useSelector } from 'react-redux';
import { useEffect , useState } from 'react';
import axios from "axios";



const ProfileInfo = () => {

  const token = useSelector((state) => state.global.token);

  
  const initialState = {
    addressLine1: '',
    addressLine2: '',
    age: '',
    applicationId: [],
    city: '',
    country: '',
    dateofBirth: '',
    email: '',
    gender: '',
    id: '',
    maritalStatus: '',
    mobile_no: '',
    name: '',
    nationality: '',
    password: '',
    pincode: '',
    role: '',
    state: '',
  };
  const [userDetails, setUserDetails] = useState(initialState);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await axios.get("http://localhost:8181/api/v1/user/getDetail", {
          headers: {
            Authorization: `Bearer ${token}`, // Assuming the token is stored in userDetails
          },
        });
        console.log(response);
        
         // Assuming response.data.data[0] contains the user details
      const userDetails = response.data.data[0];


      setUserDetails(userDetails);


      console.log(userDetails);

      } catch (error) {
        window.alert("User Details Not Fetched", error);
      }
    };
  
    fetchUserDetails();
  }, [token]);


  return (
    <div className="personal_info">
      <h2>Personal Information</h2>
      <div className="personal_container1">
        <div className="group1">
          <div className="group">
            <label>Title : </label>
            <div>Ms.</div>
          </div>
          <div className="group">
            <label>Date of Birth : </label>
            <div>{userDetails.dateofBirth}</div>
          </div>
          <div className="group">
            <label>Mobile Number : </label>
            <div>{userDetails.mobile_no}</div>
          </div>
        </div>
        <div className="group2">

        <div className="group">
          <label>Name : </label>
          <div>{userDetails.name}</div>
        </div>
        <div className="group">
          <label>Email : </label>
          <div>{userDetails.email}</div>
        </div>
        <div className="group">
          <label>Country : </label>
          <div>{userDetails.country}</div>
        </div>
        </div>
      </div>
      <h5>Additional Information</h5>
      <div className="personal_container1">
        <div className="group1">
          <div className="group">
            <label>Joining Date : </label>
            <div>{userDetails.dateofBirth}</div>
          </div>
          <div className="group">
            <label>Nationality : </label>
            <div>{userDetails.nationality}</div>
          </div>
        </div>
        <div className="group2">

        <div className="group">
          <label>State : </label>
          <div>{userDetails.state}</div>
        </div>
        <div className="group">
          <label>City : </label>
          <div>{userDetails.city}</div>
        </div>
        </div>
        <div className="group1">
          <div className="group">
            <label>addressLine1 : </label>
            <div>{userDetails.addressLine1}</div>
          </div>
          <div className="group">
            <label>addressLine2 : </label>
            <div>{userDetails.addressLine2}</div>
          </div>
        </div>
        <div className="group2">

        <div className="group">
          <label>Gender : </label>
          <div>{userDetails.gender}</div>
        </div>
        <div className="group">
          <label>Age : </label>
          <div>{userDetails.age}</div>
        </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileInfo;
