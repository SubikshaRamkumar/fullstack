
const Security = () => {
  return (
    <div>
      Security
    </div>
  )
}

export default Security
