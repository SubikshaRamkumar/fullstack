import PropTypes from "prop-types";
import "../../assets/css/singleTypes.css";
import Calculator from "../../components/user/Calculator";

const SingleTypes = ({ item }) => {
  // Helper function to render text content, splitting into lines

  const renderTextContent = (key, value) => {
    if (
      typeof value === "string" &&
      (key === "purpose" ||
        key === "objective" ||
        key === "eligibility" ||
        key === "loanAmount" ||
        key === "repaymentPeriod" ||
        key === "description")
    ) {
      // Splitting by period and space for sentences

      const lines = value.split(". ").map((line, index, array) => (
        <p key={index}>
          {line}
          {index < array.length - 1 ? "." : ""}
        </p>
      ));
      return <div>{lines}</div>;
    } else if (typeof value === "number") {
      // Handling numbers, appending '%' for rates or as needed

      return `${value}%`;
    } else {
      // Default rendering for other types

      return value;
    }
  };

  return (
    <div className="single_type_container">
      <div className="single_type_title">{item.title}</div>
      <div className="types_leftandright">
        <div className="types_left">
          <div className="type_left_ima">
            <img src={item.image}></img>
          </div>
          <div className="type_left_calc">
            <Calculator />
          </div>
        </div>
        <div className="types_right">
          {/* Dynamically render each property name and value */}
          {Object.entries(item).map(([key, value], index) => {
            if (key !== "title" && key !== "image") {
              // Skip title and image
              return (
                <div key={index} className="single_content">
                  <strong>
                    {key.charAt(0).toUpperCase() +
                      key.slice(1).replace(/_/g, " ")}
                    :
                  </strong>
                  {renderTextContent(key, value)}
                </div>
              );
            }
            return null;
          })}
        </div>
      </div>
    </div>
  );
};

SingleTypes.propTypes = {
  item: PropTypes.shape({
    title: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired, // Assuming image is a URL, so it's a string
    description: PropTypes.string.isRequired,
    scheme: PropTypes.string.isRequired,
    objective: PropTypes.string.isRequired,
    purpose: PropTypes.string.isRequired,
    loanAmount: PropTypes.string.isRequired,
    repaymentPeriod: PropTypes.string.isRequired,
    rateofInterest: PropTypes.number.isRequired,
    serviceCharges: PropTypes.number.isRequired,
  }).isRequired,
};

export default SingleTypes;
