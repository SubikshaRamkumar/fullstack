import PropTypes from "prop-types";
import "../../assets/css/single_types.css";
import Calculator from "../../components/user/Calculator";
import { useNavigate } from "react-router-dom";

const Single_Types = ({ item }) => {
  const renderTextContent = (key, value) => {
    if (
      typeof value === "string" &&
      (key === "purpose" ||
        key === "objective" ||
        key === "eligibility" ||
        key === "loan_Amount" ||
        key === "repayment_Period" ||
        key === "description")
    ) {
      // Splitting by period and space for sentences

      const lines = value.split(". ").map((line, index, array) => (
        <p key={index}>
          {line}
          {index < array.length - 1 ? "." : ""}
        </p>
      ));
      return <div>{lines}</div>;
    } else if (typeof value === "number") {
      // Handling numbers, appending '%' for rates or as needed

      return `${value}%`;
    } else {
      // Default rendering for other types

      return value;
    }
  };

  const nav = useNavigate();
  const handleApply=()=>{
    nav("/agrofunds/user/apply")
  }

  return (
    <div className="single_types_container">
      <div className="single_types_title">{item.title}</div>
      <div className="single_types_calc">
        <Calculator />
      </div>
      <div className="single_types_image">
        <img src={item.image}></img>
      </div>
      <div className="single_types_apply">
        <button className="apply_button" onClick={handleApply}>Apply</button>
      </div>
      <div className="single_types_content">
        {/* Dynamically render each property name and value */}
        {Object.entries(item).map(([key, value], index) => {
          if (key !== "title" && key !== "image") {
            // Skip title and image
            return (
              <div key={index} className="single_content">
                <strong>
                  {key.charAt(0).toUpperCase() +
                    key.slice(1).replace(/_/g, " ")}
                  :
                </strong>
                {renderTextContent(key, value)}
              </div>
            );
          }
          return null;
        })}
      </div>
    </div>
  );
};

Single_Types.propTypes = {
  item: PropTypes.shape({
    title: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired, // Assuming image is a URL, so it's a string
    description: PropTypes.string.isRequired,
    scheme: PropTypes.string.isRequired,
    objective: PropTypes.string.isRequired,
    purpose: PropTypes.string.isRequired,
    loan_Amount: PropTypes.string.isRequired,
    repayment_Period: PropTypes.string.isRequired,
    rate_of_Interest: PropTypes.number.isRequired,
    service_Charges: PropTypes.number.isRequired,
  }).isRequired,
};

export default Single_Types;
