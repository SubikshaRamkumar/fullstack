import "../../assets/css/loantypes.css";
// import SingleTypes from "../../components/user/SingleTypes";
import Single_Types from "../../components/user/Single_Types";

import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { Button, CardActionArea, CardActions } from "@mui/material";
import { useState ,useEffect } from "react";
import goldloanimg from "../../assets/images/gold loan 1.png";
import croploanimg from "../../assets/images/crop loan.png";
import machineloanimg from "../../assets/images/farm machine.png";
import landloanimg from "../../assets/images/land purchase.png";
import wareloanimg from "../../assets/images/commodity.png";
import pumpimg from "../../assets/images/pump.png";
import Livestockloanimg from "../../assets/images/livestock.png";

const TypesBox = () => {
  const [ListItems, setListItems] = useState([
    {
      title: "Agriculture Gold Loan",
      image: goldloanimg,
      scheme:"GOLD LOAN SCHEME",
      description:
        "a type of Crop Loan where loans  are primarily utilized for purchasing seeds, fertilizers, pesticides, and other inputs required for crop production against the security of Gold ornaments and coins.",
      objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
      eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
      purpose :"Finance to Agriculture, allied activities. Finance to food and agro processing activities.",
      loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
      repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
      "Rate of Interest ":7.25,
      service_Charges:0.5,
    },
    {
      title: "Crop Loans",
      image: croploanimg,
      scheme:"GOLD LOAN SCHEME",
      description:
        "specifically designed to meet the short-term financial requirements of farmers during the cultivation season, also known as Kisan Credit Card",
        objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
        eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
        purpose :"Finance to Agriculture, allied activities.Finance to food and agro processing activities.",
        loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
        repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
        rate_of_Interest:7.25,
        service_Charges:0.5,
    },
    {
      scheme:"GOLD LOAN SCHEME",
      title: "Farm Mechanization Loans",
      image: machineloanimg,
      description:
        "focuses on promoting modern agricultural practices by providing financial assistance for the purchase of farm machinery and equipment.",
        objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
        eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
        purpose :"Finance to Agriculture, allied activities.Finance to food and agro processing activities.",
        loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
        repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
        rate_of_Interest:7.25,
        service_Charges:0.5,
    },
    {
      scheme:"GOLD LOAN SCHEME",
      title: "Land Purchase Loans",
      image: landloanimg,
      description:
        "aim to facilitate the acquisition of agricultural land by landless, share croppers, small and marginal farmers, helping them expand their cultivation areas.",
        objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
        eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
        purpose :"Finance to Agriculture, allied activities.Finance to food and agro processing activities.",
        loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
        repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
        rate_of_Interest:7.25,
        service_Charges:0.5,
    },
    {
      scheme:"GOLD LOAN SCHEME",
      title: "Warehouse Receipt Loans",
      image: wareloanimg,
      description:
        "Warehouse receipt loan provide farmers with access to credit based on the value of their stored agricultural commodities.",
        objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
        eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
        purpose :"Finance to Agriculture, allied activities.Finance to food and agro processing activities.",
        loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
        repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
        rate_of_Interest:7.25,
        service_Charges:0.5,
    },
    {
      scheme:"GOLD LOAN SCHEME",
      title: "Solar Pump Set Loan",
      image: pumpimg,
      description:
        "Farmers can take advantage of solar financing to purchase a solar photovoltaic water pumping system.This agriculture loan usually is extended for a tenure of 10 years ",
        objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
        eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
        purpose :"Finance to Agriculture, allied activities.Finance to food and agro processing activities.",
        loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
        repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
        rate_of_Interest:7.25,
        service_Charges:0.5,
    },
    {
      scheme:"GOLD LOAN SCHEME",
      title: "Livestock loans",
      image: Livestockloanimg,
      description:
        "Livestock loans which are also known as loans for allied agriculture activities , are designed to meet the financial requirements of farmers involved in animal husbandry, poultry farming, or dairy farming.",
        objective:"To provide hassle-free credit to farmers to meet the emergency requirement for income generating agriculture, allied activities and food & agro processing activities.",
        eligibility:"Any individual owning gold ornaments/Jewellery/Coins, either singly or jointly. Loans can be granted against gold ornaments/Jewellery and specially minted pure gold coins sold by our bank/other bank. The total weight of the coins should not exceed 50 grams per customer. The applicant should be properly introduced to the Bank or his identity and address should be established by verifying ration card/identity card/ passport/Aadhaar Card/PAN card/similar documents acceptable to the Bank. Branches are to ensure that all KYC/AML norms are complied with for all borrowers.",
        purpose :"Finance to Agriculture, allied activities.Finance to food and agro processing activities.",
        loan_Amount:"Maximum amount of loan is restricted to Rs.5 lakhs per borrower and the loan is exclusively for the purpose of Agriculture, Allied Activities and food & agro processing activities only based on declaration.",
        repayment_Period:"Can be repaid in lump sum or in part payments but the loan must be repaid within 12 months along with accrued interest thereon.",
        rate_of_Interest:7.25,
        service_Charges:0.5,
    },
  ]);
  
  const [selectedItem, setSelectedItem] = useState(null);
  useEffect(() => {
    window.scrollTo(0, 0); // Scrolls to the top when component mounts or selectedItem changes
  }, [selectedItem]);


  const handleItemClick = (item) => {
    setSelectedItem(item);
  };

  const handleBack = () => {
    setSelectedItem(null); // Reset the selected item to null
  };


  // Conditional rendering based on whether an item is selected
  if (selectedItem) {
    return (
      <div className="types_container_bottom">
        <Single_Types item={selectedItem} />
        {/* <Single_Types item={selectedItem}/> */}
        <button onClick={handleBack} className="back_button">
          Back to Loan Types
        </button>
      </div>
    );
  }
  return (
    <div className="types_container_bottom">
      <div className="types_head">Types of Loan</div>
      <div className="diff_types">
        {ListItems.map((item, index) => {
          return (
            <div className="diff_types_box" key={index}>
              <Card
                className="card_comp"
                sx={{
                  width: 300,
                  backgroundColor: "#efebec",
                  boxShadow: "none",
                }}
              >
                <CardActionArea onClick={() => handleItemClick(item)}>
                  <Box
                    sx={{
                      position: "relative",
                      width: 300,
                      height: 150,
                      boxShadow: "1px 1px 20px #422930",
                    }}
                  >
                    <CardMedia
                      component="img"
                      sx={{
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                      }}
                      image={item.image}
                      alt="unavailable"
                    />
                    <Box
                      sx={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        background:
                          "linear-gradient(rgba(0, 0, 0, 0.2), rgba(24, 0, 92, 0.5))",
                      }}
                    ></Box>
                  </Box>
                  <CardContent sx={{ color: "#422930" }}>
                    <Typography gutterBottom variant="h5" component="div">
                      {item.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {item.description}
                    </Typography>
                  </CardContent>
                </CardActionArea>
                <CardActions>
                  <Button
                    className="types_button"
                    size="small"
                    sx={{ color: "#422930" }}
                  >
                    Apply
                  </Button>
                </CardActions>
              </Card>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TypesBox;
