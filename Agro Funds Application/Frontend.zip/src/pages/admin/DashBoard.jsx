const DashBoard = () => {
  return (
    <div>
      <p>Dashboard</p>
    </div>
  )
}

export default DashBoard
