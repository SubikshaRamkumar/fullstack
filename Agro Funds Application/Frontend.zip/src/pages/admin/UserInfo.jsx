const UserInfo = () => {
  return (
    <div>
      <p>UserInfo</p>
    </div>
  )
}

export default UserInfo
