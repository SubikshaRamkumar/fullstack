// import { useState } from "react";
import  { useRef } from "react";

import { Link } from "react-router-dom";
import "../../assets/css/login.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {useDispatch} from 'react-redux'
import { addToken, addUserData, toggleLogin } from "../../config/GlobalSlice";



const Login = () => {

  const nav = useNavigate();
  const dispatch = useDispatch();
  const emailRef = useRef("");
  const passwordRef = useRef("");
  // const[email,setEmail] = useState("");
  // const[password,setPassword] = useState("");
  // const [error, setError] = useState('');



    // const handleSubmit=(e)=>
    // {
      
    //   e.preventDefault();
    //   setError('');
    //   const users = JSON.parse(localStorage.getItem("Users")) || [];
    //   const user = users.find(user=>user.email===email && user.password===password)
    //   console.log(user);
    //   if(user)
    //   {
    //     if(email==="admin@gmail.com" && password==="admin123")
    //     {
    //       nav("/agrofunds/admin/dashbord");
    //     }
    //     else{
    //       nav("/agrofunds/user/home");

    //     }
    //   }
    //   else{
    //     // alert("No user exists or password dosent match");
    //     setError("No user or password doesn't match");
        

    //   }
      
    // }
    const handleSubmit = async (e) => {
      e.preventDefault();
      const userEmail = emailRef.current.value;
      const userPassword = passwordRef.current.value;

      try {
        const response = await axios.post("http://localhost:8181/api/v1/auth/login", {
          email: userEmail,
          password: userPassword,
          // email: email,
          // password: password,
        });
        console.log(response);
  
        const accessToken = response.data.accessToken;
        console.log(accessToken);

        if(response.status === 200){
          dispatch(toggleLogin(true));
          dispatch(addToken(accessToken));
          dispatch(addUserData({email: userEmail, password: userPassword}));
          nav("/agrofunds/user/home");
        }
        
      } catch (error) {
        console.error("Login error:", error.response ? error.response.data : error);
        window.alert("User Not Found", error);
      }
    };

  return (
    <div className="login_container">
      <div className="ima">
      </div>
      <div className="heading">
        <span className="top">LOGIN</span>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="input">
          <label htmlFor="username">Email</label>
          <input type="text" id="username" 
          // value={email} onChange={(e)=>setEmail(e.target.value)}
          ref={emailRef}
           required/>
        </div>
        <div className="input">
          <label htmlFor="password">Password</label>
          <input type="password" id="password" 
          // value={password} onChange={(e)=>setPassword(e.target.value)} 
          ref={passwordRef}
          required/>
        </div>
        

          {/* <div className="p" style={
            {
              color:"#dfd8da"
            }
          }>{error}</div> */}
        
      <div className="loginButton">
        <button className="button" type="submit">Login</button>
      </div>
      </form>
      <div className="last">
        <p>Dont have an account ? <Link to="/agrofunds/signup" className="link"><span>Register</span></Link></p>
      </div>
    </div>
  );
};

export default Login;
