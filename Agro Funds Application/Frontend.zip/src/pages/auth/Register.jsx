import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import "../../assets/css/register.css";
import { useState, useRef } from "react";
import axios from "axios";
// import { useEffect} from "react";



const Register = () => {
  const inputRef = useRef();
  const nav = useNavigate();

  // const [users, setUsers] = useState([]);

  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  // const [error, setError] = useState("");

  // useEffect(()=>{
  //   setUsers(JSON.parse(localStorage.getItem("Users"))) 
  // },[])
  // useEffect(() => {
  //   const storedUsers = JSON.parse(localStorage.getItem("Users"));
  //   if (storedUsers) {
  //     setUsers(storedUsers);
  //   }
  // }, []);

  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   setError('');

  //   if (password === confirmPassword && username.length>3 && email.length>3) {
  //     const newuser = { username, email, password };
  //     const listuser = [...users, newuser];
  //     setUsers(listuser);
  //     localStorage.setItem("Users", JSON.stringify(listuser));
  //     nav("/agrofunds/user/home");
  //   } else {
  //     // alert("Enter Proper Details");
  //     setError("Please fill your details");
  //   }
  // };

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log(username);
    console.log(email);
    console.log(password);
    console.log(confirmPassword);
    
    // const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d]{8,}$/;
    if (password !== confirmPassword) {
     window.alert("Passwords do not match.");
     return;
   }
    // if (!passwordRegex.test(password)) {
    //   window.alert("Password must contain at least 8 characters with at least one uppercase letter, one lowercase letter, and one number.");
    //   return;
    // }
    
    
    try {
      const response = await axios.post(
        "http://localhost:8181/api/v1/auth/register",
        {
          name: username,
          email: email,
          password: password,
          role:"USER"
        }
      );
      nav("/agrofunds/login")
      console.log("Success");
      console.log("API response:", response.data);
      // Handle successful response
      
    } catch (error) {
      if (error.response.status === 403) {
        console.log("Error: Forbidden (403)");
        // Handle 403 error
      } else {
        console.error("Error:", error);
        // Handle other errors
      }
    }
  };

  return (
    <div className="reg_container">
      <div className="ima"></div>
      <div className="heading">
        <span className="top">Register</span>
      </div>
      <form className="form" onSubmit={handleSubmit}>
        <div className="input">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            value={username}
            ref={inputRef}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="input">
          <label htmlFor="username">Email</label>
          <input
            type="text"
            id="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="input">
          <label htmlFor="password">Password</label>
          <input
            
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="input">
          <label htmlFor="con_password">Confirm Password</label>
          <input
            type="password"
            id="con_password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>
          {/* <p style={{color:"#dfd8da"}}>{error}</p> */}
        <div className="loginButton">
          <button
            className="button"
            type="submit"
            onClick={() => inputRef.current.focus()}
          >
            Register
          </button>
        </div>
      </form>
      <div className="last">
        <p>
          Already have an account ?{" "}
          <Link to="/agrofunds/login" className="link">
            <span>Login</span>
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
