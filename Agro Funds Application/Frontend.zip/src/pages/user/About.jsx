
const About = () => {
  return (
    <div style={{top:"90px",color:"White"}}>
      <p>About</p>
    </div>
  )
}

export default About
