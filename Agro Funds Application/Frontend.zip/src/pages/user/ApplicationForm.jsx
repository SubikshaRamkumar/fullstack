import "../../assets/css/applicationForm.css";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import { createTheme, ThemeProvider } from "@mui/material/styles";

const themeOptions = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#422930",
    },
    secondary: {
      main: "#0288d1",
    },
    text: {
      primary: "rgb(72,18,18)",
    },
  },
});

const citiesInTamilNadu = [
  "Chennai",
  "Coimbatore",
  "Madurai",
  "Tiruchirappalli",
  "Salem",
  "Tiruppur",
  "Erode",
  "Vellore",
  "Thoothukudi",
  "Dindigul",
  "Thanjavur",
  "Ranipet",
  "Sivakasi",
  "Karur",
  "Udhagamandalam",
  "Hosur",
  "Nagercoil",
  "Kanchipuram",
  "Kumbakonam",
  "Tiruvannamalai",
];

const loanTypesList = [
  "Agriculture Gold Loan",
  "Crop Loans",
  "Farm Mechanization Loans",
  "Land Purchase Loans",
  "Warehouse Receipt Loans",
  "Solar Pump Set Loan",
  "Livestock loans",
];
const indianStates = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Lakshadweep",
  "Delhi",
  "Puducherry",
];

const ApplicationForm = () => {
  return (
    <div className="whole_application_form">
      <h1>Application form</h1>
      {/* <ThemeProvider theme={themeOptions}>
      <Box
        component="form"
        sx={{
          "& > :not(style)": { m: 1, width: "25ch" },
        }}
        noValidate
        autoComplete="off"
      >
        <div className="group1">
        <TextField id="outlined-basic" label="Title" variant="outlined"  required/>
        <TextField id="outlined-basic" label="Desired Amount" variant="outlined" required/>
        </div>
      </Box>
      </ThemeProvider> */}
      <form>
        <div className="content1">
          <h3>Contact Information</h3>
          <div className="form_name">
            <div className="input_box">
              <label>TITLE :</label>
              <select className="input_name">
                <option value="">Select Title</option>
                <option value="Mr.">Mr.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Ms.">Ms.</option>
              </select>
            </div>
            <div className="input_box">
              <label>NAME :</label>
              <input type="text" className="input_name" placeholder="Enter your name"></input>
            </div>
            <div className="input_box">
              <label>MOBILE NUMBER :</label>
              <input type="text" className="input_name" placeholder="Enter your mobile number"></input>
            </div>
          </div>
          <div className="form_name">
            <div className="input_box">
              <label>DOB :</label>
              <input type="date" className="input_name" placeholder="Enter you date of birth"></input>
            </div>
            <div className="input_box">
              <label>AGE :</label>
              <input type="number" className="input_name" placeholder="Enter your age"></input>
            </div>
            <div className="input_box">
              <label>EMAIL :</label>
              <input type="email" className="input_name" placeholder="Enter you email id"></input>
            </div>
          </div>
          <div
            className="form_name"
            style={{ marginTop: "10px", width: "70%" }}
          >
            <div className="input_box">
              <label>GENDER :</label>
              <div className="gender_options">
                <label>
                  <input type="radio" name="gender" value="male" /> Male
                </label>
                <label>
                  <input type="radio" name="gender" value="female" /> Female
                </label>
                <label>
                  <input type="radio" name="gender" value="other" /> Other
                </label>
              </div>
            </div>
            <div className="input_box">
              <label>MARITAL STATUS :</label>
              <div className="marital_options">
                <label>
                  <input type="radio" name="marital" value="married" /> Married
                </label>
                <label>
                  <input type="radio" name="marital" value="unmarried" />{" "}
                  Unmarried
                </label>
                <label>
                  <input type="radio" name="marital" value="other" /> Other
                </label>
              </div>
            </div>
          </div>
          <div className="form_address">
            <div className="input_box">
              <label>Adress Line 1 :</label>
              <input type="text" className="input_name"placeholder="Enter your Address line 1"></input>
            </div>
            <div className="input_box">
              <label>Adress Line 2 :</label>
              <input type="text" className="input_name" placeholder="Enter your Address line 2"></input>
            </div>
            <div className="city_state">
              <div className="input_box">
                <label>CITY :</label>
                <select className="input_name">
                  <option value="">Select City</option>
                  {citiesInTamilNadu.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>
              <div className="input_box">
                <label>STATE :</label>
                <select className="input_name">
                  <option value="">Select State</option>
                  {indianStates.map((state) => (
                    <option key={state} value={state}>
                      {state}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="input_box">
              <label>PINCODE :</label>
              <input
                type="text"
                className="input_name"
                style={{ width: "22.5%" }}
                placeholder="Enter your pincode"
              ></input>
            </div>
            <div className="input_box">
              <label>How long have you lived in your given address ?</label>
              <div className="Years_lived_options">
                <label>
                  <input type="radio" name="marital" value="married" />
                  <span> 0-1 Year</span>
                </label>
                <label>
                  <input type="radio" name="marital" value="unmarried" />
                  <span>1-2 Years</span>
                </label>
                <label>
                  <input type="radio" name="marital" value="other" />
                  <span> 3-4 Years</span>
                </label>
                <label>
                  <input type="radio" name="marital" value="other" />
                  <span>5+ Years</span>
                </label>
              </div>
            </div>
          </div>
        </div>
        <div className="content2">
          <h3>Loan Information</h3>
          <div className="form_name">
            <div className="input_box">
              <label>Desired Loan Amount :</label>
              <input type="number" className="input_name" placeholder="Enter your desired Loan Amount"></input>
            </div>
            <div className="input_box">
              <label>Annual Income :</label>
              <input type="number" className="input_name" placeholder="Enter your Annual Income"></input>
            </div>
          </div>
          <div className="form_name">
            <div className="input_box">
              <label>Date of Application :</label>
              <input type="date" className="input_name"></input>
            </div>
            <div className="input_box">
              <label>LOAN TYPE :</label>
              <select className="input_name">
                <option value="">Select Type</option>
                {loanTypesList.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <div className="button_application">
          <button className="Apply_loan_button">Submit</button>
        </div>
      </form>
    </div>
  );
};

export default ApplicationForm;
