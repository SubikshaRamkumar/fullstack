import "../../assets/css/contact.css";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import {
//   faEnvelope,faPhone,faClock,
//   faMap
// } from "@fortawesome/free-brands-svg-icons";
import CallIcon from "@mui/icons-material/Call";
import MailOutlineIcon from "@mui/icons-material/MailOutline";
import MapIcon from "@mui/icons-material/Map";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import p1 from "../../assets/images/1.png";
import p2 from "../../assets/images/2.png";
import p3 from "../../assets/images/3.png";
// import { faMap } from "@fortawesome/free-regular-svg-icons";
const Contact = () => {
  return (
    <div className="full_contact">
      <div className="contact_main_head">
          <div className="contact_box">
            <div className="contact_first_line">
            Reach out today and unlock endless possibilities             </div>
            <div className="contact_second_line">
            We're here to turn your visions into reality
            </div>
          </div>
        </div>
      <div id="contact-details" className="section-p1">
        <div className="contact-info">
          <span>GET IN TOUCH</span>
          <h1>Visit one of our agency location or contact us today</h1>
          <h3>Head office</h3>
          <div className="contact-options">
            <li>
              <MapIcon className="contact_icon" />
              <p>25, Sri prasanna Avenue Anaikkadu , Hyderabad </p>
            </li>
            <li>
              <MailOutlineIcon className="contact_icon" />
              <p>Cara@gmail.com</p>
            </li>
            <li>
              <CallIcon className="contact_icon" />
              <p>Helo@gmail.com</p>
            </li>
            <li>
              <AccessTimeIcon className="contact_icon" />
              <p>Monday to Saturday : 9:00am to 20pm</p>
            </li>
          </div>
        </div>
        <div className="map">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d121832.29960384466!2d78.39000122873078!3d17.3993364265351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9918de35dd01%3A0x2b75efae64572a10!2sVijetha%20Super%20Market%20Himayathnagar!5e0!3m2!1sen!2sin!4v1692715644988!5m2!1sen!2sin"
            width="600"
            height="450"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>
      <div id="form-details">
        <form>
          <span>LEAVE A MESSAGE</span>
          <h1>We love to hear from you</h1>
          <input type="text" placeholder="Your name" />
          <input type="text" placeholder="E-mail" />
          <input type="text" placeholder="Subject" />
          <textarea
            name=""
            id=""
            cols="30"
            rows="10"
            placeholder="Your Message"
          ></textarea>
          <button className="contact_button">Submit</button>
        </form>
        <div className="people">
          <div>
            <img src={p1} />
            <p>
              <span>Subiksha</span> Senior Marketing Manager <br></br>Phone :
              +91 9361866588<br></br>
              Email : subi@gmail.com
            </p>
          </div>
          <div>
            <img src={p2} />
            <p>
              <span>Ram</span> Senior Marketing Manager <br></br>Phone : +91
              9361866588<br></br>
              Email : ram@gmail.com
            </p>
          </div>
          <div>
            <img src={p3} />
            <p>
              <span>sedhu</span> Senior Marketing Manager <br></br>Phone : +91
              9361866588<br></br>
              Email : sedhu@gmail.com
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
