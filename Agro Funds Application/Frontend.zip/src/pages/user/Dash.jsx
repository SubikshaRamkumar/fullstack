import "../../assets/css/dashboardUser.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Dashboard from "./Dashboard";
import Calculator from "../../components/user/Calculator";
import EmiDetails from "../../components/user/EmiDetails";
import Profile from "./Profile";
import EditProfile from "./EditProfile";
const Dash = () => {
  const nav = useNavigate();

  const [listData, setListData] = useState([
    {
      loanId: 1,
      loanType: "Agricultural Gold Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "pending",
    },
    {
      loanId: 2,
      loanType: "Crop Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "pending",
    },
    {
      loanId: 3,
      loanType: "Farm Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "Completed",
    },
    {
      loanId: 4,
      loanType: "Machine Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "pending",
    },
  ]);
  
  // State to keep track of the selected item
  const [selectedItem, setSelectedItem] = useState("Dashboard");

  // Function to handle item click
  const handleItemClick = (itemName) => {
    setSelectedItem(itemName);
  };


  const handleLogout=()=>{
  
    // Display a confirmation dialog
    const isConfirmed = window.confirm("Are you sure you want to logout?");

    // If the user confirms, redirect to the logout page
    if (isConfirmed) {
      nav("/agrofunds/login");
    }
  }
  // Function to render the right component based on the selected item
  const renderRightComponent = () => {
    switch (selectedItem) {
      case "Dashboard":
        return <Dashboard />;
      case "Loan Details":
        return <EmiDetails listData={listData}/>;
      case "Loan Calculator":
        return <Calculator />;
      case "Profile":
        return <Profile />;
      case "Edit Profile":
        return <EditProfile />;
      default:
        return null;
    }
  };

  return (
    <div className="whole_User">
      <div className="whole_left">
        <div className="whole_top"></div>
        <div className="whole_bottom">
          <div className="item" onClick={() => handleItemClick("Dashboard")}>
            Dashboard
          </div>
          <div className="item" onClick={() => handleItemClick("Loan Details")}>
            Loan Details
          </div>
          <div
            className="item"
            onClick={() => handleItemClick("Loan Calculator")}
          >
            Loan Calculator
          </div>
          <div className="item" onClick={() => handleItemClick("Profile")}>
            My Profile
          </div>
          <div className="item" onClick={() => handleItemClick("Edit Profile")}>
            Edit Profile
          </div>
          <div className="item" onClick={handleLogout}>
            Logout
          </div>
        </div>
      </div>
      <div className="whole_right">
      {renderRightComponent()}
      </div>
    </div>
  );
};

export default Dash;
