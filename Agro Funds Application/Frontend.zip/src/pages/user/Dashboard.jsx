import "../../assets/css/dashboard.css";
import { useState, useEffect } from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import Paper from "@mui/material/Paper";
import EmiDetails from "../../components/user/EmiDetails";
import { useSelector } from "react-redux";
// import ArrowRightAltIcon from "@mui/icons-material/ArrowRightAlt";

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
    backgroundColor: "#efebec",
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const Dashboard = () => {
  const userDetails = useSelector((state) => state.global.userData);

  const [listData, setListData] = useState([
    {
      loanId: 1,
      loanType: "Agricultural Gold Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "pending",
    },
    {
      loanId: 2,
      loanType: "Crop Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "Rejected",
    },
    {
      loanId: 3,
      loanType: "Farm Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "Approved",
    },
    {
      loanId: 4,
      loanType: "Machine Loan",
      date: "2024-08-12",
      amount: "1000000",
      status: "pending",
    },
  ]);
  const [listRepayment, setListRepayment] = useState([]);

  useEffect(() => {
    // Filter listData to get only items with status "Approved"
    const approvedRepayments = listData.filter(
      (item) => item.status === "Approved"
    );
    setListRepayment(approvedRepayments);
  }, [listData]);

  return (
    <div className="Whole_dashboard">
      <div className="whole_dashBoard_top">
        <div className="top_content">
          <h5>Welcome !</h5>
          <h1>{userDetails.email.split('@')[0]}</h1>          
          <p>At a glance summary of your account. Have fun!</p>
        </div>
        {/* <div className="top_button">
          <button className="top_button_profile">
            <div className="inside_buton">
              Profile
              <ArrowRightAltIcon />
            </div>
          </button>
        </div> */}
      </div>
      <div className="whole_dashBoard_hisotry">
        <h4>Loan Application</h4>
        <TableContainer component={Paper} style={{ maxWidth: "100%" }}>
          <Table sx={{ minWidth: 700 }} aria-label="customized table">
            <TableHead
              style={{
                backgroundColor: "#422930",
              }}
            >
              <TableRow>
                <TableCell className="history_head">Loan Id</TableCell>
                <TableCell className="history_head">Loan Type</TableCell>
                <TableCell className="history_head">Date</TableCell>
                <TableCell className="history_head">Amount</TableCell>
                <TableCell className="history_head">Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {listData.map((row) => (
                <StyledTableRow key={row.loanId}>
                  <TableCell component="th" scope="row">
                    {row.loanId}
                  </TableCell>

                  <TableCell>{row.loanType}</TableCell>
                  <TableCell>{row.date}</TableCell>
                  <TableCell>{row.amount}</TableCell>
                  <TableCell>{row.status}</TableCell>
                </StyledTableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <h4>Repayment</h4>
        <TableContainer component={Paper} style={{ maxWidth: "100%" }}>
          <Table sx={{ minWidth: 700 }} aria-label="customized table">
            <TableHead
              style={{
                backgroundColor: "#422930",
              }}
            >
              <TableRow>
                <TableCell className="history_head">Loan Id</TableCell>
                <TableCell className="history_head">Loan Type</TableCell>
                <TableCell className="history_head">Date</TableCell>
                <TableCell className="history_head">Amount</TableCell>
                <TableCell className="history_head">Total Tenure Months</TableCell>
                <TableCell className="history_head">Paid Months</TableCell>
                <TableCell className="history_head">Remaining Months</TableCell>
                <TableCell className="history_head">Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {listRepayment.map((row) => (
                <StyledTableRow key={row.loanId}>
                  <TableCell component="th" scope="row">
                    {row.loanId}
                  </TableCell>

                  <TableCell>{row.loanType}</TableCell>
                  <TableCell>{row.date}</TableCell>
                  <TableCell>{row.amount}</TableCell>
                  <TableCell>{row.status}</TableCell>
                </StyledTableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      <div className="emi_overview">
        <EmiDetails listData={listData} />
      </div>
    </div>
  );
};

export default Dashboard;
