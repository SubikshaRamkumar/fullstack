import "../../assets/css/editProfile.css";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import axios from "axios";

const EditProfile = () => {
  const token = useSelector((state) => state.global.token);

  const initialState = {
    addressLine1: "",
    addressLine2: "",
    age: "",
    city: "",
    country: "",
    dateofBirth: "",
    email: "",
    id: "",
    gender: "male",
    maritalStatus: "unmarried",
    mobile_no: "",
    name: "",
    nationality: "",
    pincode: "",
    state: "",
  };
  const [userDetails, setUserDetails] = useState(initialState);
  // const [userDetails, setUserDetails] = useState([]);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8181/api/v1/user/getDetail",
          {
            headers: {
              Authorization: `Bearer ${token}`, // Assuming the token is stored in userDetails
            },
          }
        );
        console.log(response);
        const fetchedDetails = response.data.data[0] || {};
        const detailsToSet = {
          ...initialState, // Spread all properties of initialState
          ...Object.keys(fetchedDetails).reduce((acc, key) => {
            // Only add properties that exist in fetchedDetails and are not null
            acc[key] = fetchedDetails[key] === null ? "" : fetchedDetails[key];
            return acc;
          }, {}),
        };

        setUserDetails(detailsToSet);
        console.log("HI");
      } catch (error) {
        window.alert("User Details Not Fetched", error);
      }
    };

    fetchUserDetails();
  }, [token]);

  const handleUpdate = async (e) => {
    e.preventDefault(); // Prevent form from submitting the traditional way
    const post = {
      addressLine1: userDetails.addressLine1,
      addressLine2: userDetails.addressLine2,
      age: userDetails.age,
      city: userDetails.city,
      country: userDetails.country,
      dateofBirth: userDetails.dateofBirth,
      email: userDetails.email,
      gender: userDetails.gender,
      maritalStatus: userDetails.maritalStatus,
      mobile_no: userDetails.mobile_no,
      name: userDetails.name,
      nationality: userDetails.nationality,
      pincode: userDetails.pincode,
      state: userDetails.state,
    };
    try {
      // Construct the update URL using the user's ID
      // const updateUrl = `http://localhost:8181/api/v1/user/update/${userDetails.id}`;
      // const response = await axios.put(updateUrl, post
      // console.log("qwkfjoifnf "+userDetails.id);
      // const response = await axios.put(`http://localhost:8181/api/v1/user/update`, post
      const response = await axios.put(`http://localhost:8181/api/v1/user/update/${post.id}`, post
        , 
        {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json', // Ensuring the server knows we're sending JSON

        },
        
      }
      );
      console.log(response);
      alert("Profile updated successfully!");
    } catch (error) {
      console.error("Profile Update Failed", error);
      window.alert("Profile Update Failed", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    console.log(`Updating: ${name} to ${value}`); // Debugging line
    setUserDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    }));
  };

  return (
    <div className="Whole_editProfile">
      <div className="head">
        <h2>Edit Profile</h2>
      </div>
      <form onSubmit={handleUpdate}>
        <div className="section_head">
          <h3>Personal Information</h3>
          <div className="oneRow_container">
            <div className="input_box">
              <label>NAME :</label>
              <input
                name="name"
                type="text"
                className="input_name"
                placeholder="Enter your name"
                value={userDetails.name}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className="input_box">
              <label>EMAIL :</label>
              <input
                type="email"
                name="email"
                className="input_name"
                placeholder="Cant Enter your number"
                value={userDetails.email}
                disabled
              ></input>
            </div>
          </div>

          <div className="oneRow_container">
            {/* <div className="input_box">
              <label>DATE OF BIRTH :</label>
              <input
                type="date"
                name="dateofBirth"
                className="input_name"
                placeholder="Enter your date of birth"
                value={userDetails.dateofBirth}
                onChange={handleInputChange}
              ></input>
            </div> */}
            <div className="input_box">
              <label>AGE :</label>
              <input
                type="number"
                name="age"
                className="input_name"
                placeholder="Enter your name"
                value={userDetails.age}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>
          <div className="oneRow_container">
            <div className="input_box">
              <label>NATIONALITY : </label>
              <input
                type="text"
                name="nationality"
                className="input_name"
                placeholder="Enter your nationality"
                value={userDetails.nationality}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>
          <div className="oneRow_container">
            <div className="form_name">
              <div className="input_box">
                <label>GENDER :</label>
                <div className="gender_options">
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="male"
                      checked={userDetails.gender === "male"}
                      onChange={handleInputChange}
                    />{" "}
                    Male
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="female"
                      checked={userDetails.gender === "female"}
                      onChange={handleInputChange}
                    />{" "}
                    Female
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="other"
                      checked={userDetails.gender === "other"}
                      onChange={handleInputChange}
                    />{" "}
                    Other
                  </label>
                </div>
              </div>
              <div className="input_box">
                <label>MARITAL STATUS :</label>
                <div className="marital_options">
                  <label>
                    <input
                      type="radio"
                      name="maritalStatus"
                      value="married"
                      checked={userDetails.maritalStatus === "married"}
                      onChange={handleInputChange}
                    />
                    Married
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="maritalStatus"
                      value="unmarried"
                      checked={userDetails.maritalStatus === "unmarried"}
                      onChange={handleInputChange}
                    />
                    Unmarried
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="maritalStatus"
                      value="other"
                      checked={userDetails.maritalStatus === "other"}
                      onChange={handleInputChange}
                    />{" "}
                    Other
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="section_head">
          <h3>Contact Information</h3>
          <div className="oneRow_container">
            <div className="input_box">
              <label>MOBILE NO :</label>
              <input
                type="number"
                name="mobile_no"
                className="input_name"
                placeholder="Enter your number"
                value={userDetails.mobile_no}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className="input_box">
              <label>MOBILE NO :</label>
              <input
                type="number"
                name="mobile_no"
                className="input_name"
                placeholder="Enter your number"
                value={userDetails.mobile_no}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>

          <div className="oneRow_container">
            <div className="input_box">
              <label>Address Line 1 :</label>
              <input
                type="text"
                name="addressLine1"
                className="input_name"
                placeholder="Enter your address line 1"
                value={userDetails.addressLine1}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className="input_box">
              <label>Address Line 2 :</label>
              <input
                type="text"
                name="addressLine2"
                className="input_name"
                placeholder="Enter your address line 2"
                value={userDetails.addressLine2}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>
          <div className="oneRow_container">
            <div className="input_box">
              <label>CITY : </label>
              <input
                type="text"
                name="city"
                className="input_name"
                placeholder="Enter your city"
                value={userDetails.city}
                onChange={handleInputChange}
              ></input>
            </div>
            <div className="input_box">
              <label>STATE : </label>
              <input
                type="text"
                name="state"
                className="input_name"
                placeholder="Enter your state"
                value={userDetails.state}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>
          <div className="oneRow_container">
            <div className="input_box">
              <label>PINCODE : </label>
              <input
                type="number"
                name="pincode"
                className="input_name"
                placeholder="Enter your pincode"
                value={userDetails.pincode}
                onChange={handleInputChange}
              ></input>
            </div>
          </div>
        </div>
        <div className="button_edit">
          <button className="eidt_button">Submit</button>
        </div>
      </form>
    </div>
  );
};

export default EditProfile;
