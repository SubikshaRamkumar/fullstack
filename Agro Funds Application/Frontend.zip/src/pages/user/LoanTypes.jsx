import "../../assets/css/loantypes.css";
import TypesBox from "../../components/user/TypesBox";



const LoanTypes = () => {
  

  return (
    <div>
      <div className="types_container">
        <div className="types_main_head">
          <div className="types_box">
            <div className="types_first_line">
              Empower your farming journey with tailored agriculture loans
            </div>
            <div className="types_second_line">
              Elevate productivity, modernize operations, and secure a
              flourishing future for Indian agriculture!
            </div>
          </div>
        </div>
        <TypesBox/>
      </div>
    </div>
  );
};

export default LoanTypes;
