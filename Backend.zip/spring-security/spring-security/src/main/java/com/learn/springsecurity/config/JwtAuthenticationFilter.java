package com.learn.springsecurity.config;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

import java.io.IOException;

import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.learn.springsecurity.repository.TokenRepository;
import com.learn.springsecurity.utils.JwtUtil;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

// . This setup is essential for securing your application, ensuring that each request is properly authenticated and authorized based on JWTs before reaching your business logic.
@Component // @Component, making it a Spring-managed bean. Spring will automatically detect this filter and include it in its application context.
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;
    private final TokenRepository tokenRepository;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain)
            throws ServletException, IOException {
        final String authHeader = request.getHeader(AUTHORIZATION);
        final String jwtToken;
        final String userEmail;
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }
        jwtToken = authHeader.substring(7);
        userEmail = jwtUtil.extractUsername(jwtToken);
        if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {  //getContext(): This method retrieves the current SecurityContext. The SecurityContext is where the authentication details are stored.
            // The Authentication object contains the principal's information, such as the currently authenticated user's details and their granted authorities (roles/permissions).
            // his checks if the Authentication object is null. If it is null, it means there is currently no authenticated user for this session/request.
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail);


            var isTokenValid = tokenRepository.findByToken(
                    jwtToken)
                    .map(token -> !token.isExpired() && !token.isRevoked())
                    .orElse(false);

            if (jwtUtil.isTokenValid(jwtToken, userDetails) && isTokenValid) {

                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
                null, userDetails.getAuthorities());  //The second parameter is null because the user is authenticated via JWT, not a password submitted during the current request.
                
                
                // This line attaches additional details about the current HTTP request to the authentication token. These details can include the IP address, session ID, etc., and can be used in later security decisions or logging.
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                
                SecurityContextHolder.getContext().setAuthentication(authToken); //inally, the authenticated token is stored in the SecurityContext via SecurityContextHolder
            }
        }
        filterChain.doFilter(request, response);
    }
}


// JwtAuthenticationFilter acts as a gatekeeper, ensuring that only requests with valid JWTs proceed with an authenticated user context. It leverages the JwtUtil for JWT parsing and validation, UserDetailsService for loading user-specific data, and TokenRepository for additional token integrity checks