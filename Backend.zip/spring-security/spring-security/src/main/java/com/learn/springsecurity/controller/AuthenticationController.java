package com.learn.springsecurity.controller;

import static com.learn.springsecurity.utils.MyConstant.AUTH;
import static com.learn.springsecurity.utils.MyConstant.LOGIN;
import static com.learn.springsecurity.utils.MyConstant.REFRESR_TOKEN;
import static com.learn.springsecurity.utils.MyConstant.REGISTER;
import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.EXPECTATION_FAILED;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springsecurity.dto.request.LoginRequest;
import com.learn.springsecurity.dto.request.RegisterRequest;
import com.learn.springsecurity.dto.response.LoginResponse;
import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.service.AuthenticationService;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;





@RestController   //The class is structured to manage user registration, login, and token refresh operations.  and response body of the methods will automatically serialize return objects into JSON or XML

@RequestMapping(AUTH)
@Tag(name = "Authentication")  //Used by Swagger/OpenAPI for API documentation. It groups all endpoints in this controller under the "Authentication" tag.
@RequiredArgsConstructor
public class AuthenticationController {

    private final AuthenticationService authService;  //immutable

    @PostMapping(REGISTER)
    public ResponseEntity<RegisterResponse> register(@RequestBody RegisterRequest request) {
        RegisterResponse response = new RegisterResponse();
        try {
            response = authService.register(request);
            return new ResponseEntity<>(response, ACCEPTED);
        } catch (Exception e) {
            response.setMessage("Registration failed due to an unexpected error.");
            return new ResponseEntity<>(response, EXPECTATION_FAILED);
        }
    }


    //to authenticate the user based on the provided credentials in LoginRequest and return a LoginResponse object containing the login operation's result, including an access token if the login is successful.
    @PostMapping(LOGIN) 
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {  //ResponseEntity object wrapping a LoginResponse, allowing for a response body and HTTP status code to be sent back to the client.
        LoginResponse response = new LoginResponse();
        try {
            response = authService.login(request);
            return new ResponseEntity<>(response, ACCEPTED);
        } catch (Exception e) {
            response.setMessage("Login failed!");
            response.setAccessToken("");  //to signify that no valid token is being returned.
            return new ResponseEntity<>(response, EXPECTATION_FAILED);
        }
    }

    @PostMapping(REFRESR_TOKEN)   //Refresh tokens solve this problem by allowing the system to issue new access tokens without requiring the user to manually re-authenticate.
    public void refreshToken(
            HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        authService.refreshToken(request, response);
    }
}


// working of refresh tokens 


// The refresh token mechanism works as part of a token-based authentication system, providing a way to renew access tokens without requiring the user to repeatedly log in. This process is crucial for maintaining both security and a seamless user experience. Here's a step-by-step explanation of how it works:

// Initial User Authentication
// User Login: The user submits their credentials (e.g., username and password) to the authentication server.
// Verification: The authentication server verifies the credentials. If they're valid, it issues two types of tokens: an access token and a refresh token.
// Access Token: A short-lived token used to access protected resources. It contains claims about the user (e.g., user ID, roles) and has a limited validity period (e.g., 15 minutes to 1 hour).
// Refresh Token: A longer-lived token used solely to obtain new access tokens. It's usually stored securely on the client side and sent to the server only when requesting a new access token.
// Accessing Protected Resources
// Access Token Use: The client uses the access token to make authenticated requests to resource servers. The resource server validates the access token and, if valid, serves the request.
// Token Expiration: Eventually, the access token expires. Any attempt to access resources with an expired token results in an authentication error.
// Token Refresh Process
// Refresh Request: When the access token expires, the client sends a request to the authentication server to refresh it. This request includes the refresh token.
// Validation: The authentication server validates the refresh token. This validation might involve checking if the token is expired, if it has been revoked, or if the session associated with it is still active.
// Issuing New Tokens: If the refresh token is valid, the authentication server issues a new access token (and possibly a new refresh token). The new access token can then be used by the client to access protected resources.
// Response: The client receives the new access token (and refresh token, if applicable) and resumes accessing the resources without requiring the user to manually re-authenticate.
// Security Considerations
// Storage: Refresh tokens are powerful and must be stored securely to prevent misuse. If a refresh token is stolen, an attacker could potentially generate new access tokens.
// Revocation: The authentication server should support revoking refresh tokens, enabling sessions to be ended immediately in case of suspicious activity or user logout.
// Rotation: Issuing a new refresh token with each access token renewal can help limit the impact of a refresh token being compromised. The old refresh token is invalidated, and only the most recently issued refresh token is valid.
// Implementation
// In the code snippet you provided, the refreshToken method likely handles the refresh request from the client. It would extract the refresh token from the request, validate it, generate a new access token, and send the new access token back to the client. This method helps automate the process of token renewal, ensuring that users remain authenticated and can continue to access resources without interruption, all while maintaining a high level of security.