package com.learn.springsecurity.controller;

import static com.learn.springsecurity.utils.MyConstant.FORGOT_PASSWORD;
import static com.learn.springsecurity.utils.MyConstant.USER;

import java.security.Principal;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learn.springsecurity.dto.request.PasswordRequest;
import com.learn.springsecurity.dto.response.dtos.UserDto;
import com.learn.springsecurity.model.User;
import com.learn.springsecurity.service.UserService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController  // every method return a domain object  . It's shorthand for including both @Controller and @ResponseBody.

@RequestMapping(USER)  // base URI

@PreAuthorize("hasAnyRole('USER', 'ADMIN')")  // only 'USER' or 'ADMIN' roles can access the methods in this controller.

@Tag(name = "USER")  //A Swagger/OpenAPI annotation that groups all the controller's endpoints under the "USER" tag in the generated API documentation.

@RequiredArgsConstructor  //A Lombok annotation that generates a constructor with one parameter for each field that is final. This is used for dependency injection of the UserService.

public class UserController {

    private final UserService userService;  //final keyword indicates that this dependency must be initialized during the construction of UserController, which Spring handles automatically due to the @RequiredArgsConstructor annotation.

    @GetMapping
    @PreAuthorize("hasAnyAuthority('user:read', 'admin:read')")
    public String get() {
        return "GET:: user controller";
    }

    @PatchMapping(FORGOT_PASSWORD)
    @PreAuthorize("hasAnyAuthority('user:update', 'admin:update')")
    @Hidden   //This annotation from Swagger/OpenAPI suggests that this endpoint should be omitted from the generated API documentation, perhaps for security reasons or because it's not intended to be publicly documented.
    public ResponseEntity<?> forgotPassword(PasswordRequest request, Principal principal) {  //PasswordRequest likely contains the necessary information for updating the password (e.g., current password, new password), while the Principal object represents the currently authenticated user.
        userService.forgotPassword(request, principal);
        return ResponseEntity.ok().body("Password changed successfully");
    }

    // Fetch User Details by Principal  object, which represents the currently authenticated user, to fetch user details directly related to the authenticated user. It's a straightforward approach when you need to return details of the currently logged-in user.
    @GetMapping("/details")
    @PreAuthorize("hasAnyAuthority('user:read', 'admin:read')")
    public ResponseEntity<?> getUserDetails(Principal principal) 
    {
        UserDto userDetailDto = userService.getUserDetailsByEmail(principal.getName());
        return new ResponseEntity<>(userDetailDto,HttpStatus.OK);
    }

    //Fetch User Details by ID . If you want to fetch details for any user (not just the authenticated one), and your users have unique IDs,  add a method to fetch user details by their ID. This approach requires securing the endpoint to ensure only authorized users can access it.
    // @GetMapping("/{userId}")
    // @PreAuthorize("hasAuthority('user:read') || @userService.isSelf(principal, #userId)")
    // public ResponseEntity<?> getUserDetailsById(@PathVariable Long userId) {
    //     UserDto userDetailDto = userService.getUserDetailsById(userId);
    //     return new ResponseEntity<>(userDetailDto,HttpStatus.OK);
    // }

    // @GetMapping("/{userId}")
    // @PreAuthorize("@userService.canAccessUserDetails(#userId)")
    // public ResponseEntity<?> getUserDetailsById(@PathVariable Long userId) {
    // UserDto userDetailDto = userService.getUserDetailsById(userId);
    // return ResponseEntity.ok(userDetailDto);
    // }

}
