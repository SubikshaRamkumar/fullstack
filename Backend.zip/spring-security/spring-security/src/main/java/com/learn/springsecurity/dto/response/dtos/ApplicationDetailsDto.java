package com.learn.springsecurity.dto.response.dtos;

import java.util.Set;

import com.learn.springsecurity.model.LoanTypes;
import com.learn.springsecurity.model.RepaymentDetails;
import com.learn.springsecurity.model.Transaction;
import com.learn.springsecurity.model.User;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ApplicationDetailsDto {
    
    private Long applicationId;

    private String application_date;

    private String loan_amt_requested;

    private String tenure_in_months;
    
    private String application_status;

    private String approval_date;

    private User user;

    private LoanTypes loanType;

    private Transaction transaction;

    private Set<RepaymentDetails> repayments;
}
