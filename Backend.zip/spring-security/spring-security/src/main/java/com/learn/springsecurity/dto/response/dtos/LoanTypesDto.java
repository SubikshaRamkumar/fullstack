package com.learn.springsecurity.dto.response.dtos;

import java.util.Set;

import com.learn.springsecurity.model.ApplicationDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class LoanTypesDto {
    private Long LoanId;

    private String loan_title;

    private String scheme;

    private String description;

    private String objective;

    private String eligibility;

    private String loan_amount;

    private String repayment_period;
    
    private String rate_of_interest;
    
    private String service_charge;

    private Set<ApplicationDetails> applicationDetails;
}
