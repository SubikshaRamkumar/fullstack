package com.learn.springsecurity.dto.response.dtos;

import com.learn.springsecurity.model.ApplicationDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RepaymentDetailDto {
    
    private Long repaymentId;

    private String payment_date;

    private String amount_paid;

    private String balance_amt;

    private String total_amount;

    private String paid_months;

    private String due_months;

    private ApplicationDetails applicationDetail;
}
