package com.learn.springsecurity.dto.response.dtos;

import com.learn.springsecurity.model.ApplicationDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TransactionDto {
    
    private Long transactionId;

    private String transaction_amount;

    private String transaction_date;

    private String transaction_status;

    private ApplicationDetails applicationDetail;
}
