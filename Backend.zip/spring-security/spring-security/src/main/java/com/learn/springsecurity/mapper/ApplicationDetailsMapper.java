package com.learn.springsecurity.mapper;

import com.learn.springsecurity.dto.response.dtos.ApplicationDetailsDto;
import com.learn.springsecurity.model.ApplicationDetails;

public class ApplicationDetailsMapper {
    public static ApplicationDetailsDto mApplicationDetailsDto(ApplicationDetails applicationDetails)
    {
        return ApplicationDetailsDto.builder()
                .applicationId(applicationDetails.getApplicationId())
                .application_date(applicationDetails.getApplication_date())
                .loan_amt_requested(applicationDetails.getLoan_amt_requested())
                .tenure_in_months(applicationDetails.getTenure_in_months())
                .application_status(applicationDetails.getApplication_status())
                .approval_date(applicationDetails.getApproval_date())
                .user(applicationDetails.getUser())
                .loanType(applicationDetails.getLoanType())
                .transaction(applicationDetails.getTransaction())
                .repayments(applicationDetails.getRepayments())
                .build();
    }
    public static ApplicationDetails mApplicationDetails(ApplicationDetailsDto applicationDetailsdDto)
    {
        return ApplicationDetails.builder()
                .applicationId(applicationDetailsdDto.getApplicationId())
                .application_date(applicationDetailsdDto.getApplication_date())
                .loan_amt_requested(applicationDetailsdDto.getLoan_amt_requested())
                .tenure_in_months(applicationDetailsdDto.getTenure_in_months())
                .application_status(applicationDetailsdDto.getApplication_status())
                .approval_date(applicationDetailsdDto.getApproval_date())
                .user(applicationDetailsdDto.getUser())
                .loanType(applicationDetailsdDto.getLoanType())
                .transaction(applicationDetailsdDto.getTransaction())
                .repayments(applicationDetailsdDto.getRepayments())
                .build();
    }
}
