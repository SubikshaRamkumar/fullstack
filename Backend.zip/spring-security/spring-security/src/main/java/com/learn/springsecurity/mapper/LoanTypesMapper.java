package com.learn.springsecurity.mapper;

import com.learn.springsecurity.dto.response.dtos.LoanTypesDto;
import com.learn.springsecurity.model.LoanTypes;

public class LoanTypesMapper {
    public static LoanTypesDto mapToTransactionDto(LoanTypes loanTypes)
    {
        return LoanTypesDto.builder()
                .LoanId(loanTypes.getLoanId())
                .loan_title(loanTypes.getLoan_title())
                .scheme(loanTypes.getScheme())
                .description(loanTypes.getDescription())
                .objective(loanTypes.getObjective())
                .eligibility(loanTypes.getEligibility())
                .loan_amount(loanTypes.getLoan_amount())
                .repayment_period(loanTypes.getRepayment_period())
                .rate_of_interest(loanTypes.getRate_of_interest())
                .service_charge(loanTypes.getService_charge())
                .applicationDetails(loanTypes.getApplicationDetails())
                .build();
    }
    public static LoanTypes mapToTransaction(LoanTypesDto loanTypesDto)
    {
        return LoanTypes.builder()
                .LoanId(loanTypesDto.getLoanId())
                .loan_title(loanTypesDto.getLoan_title())
                .scheme(loanTypesDto.getScheme())
                .description(loanTypesDto.getDescription())
                .objective(loanTypesDto.getObjective())
                .eligibility(loanTypesDto.getEligibility())
                .loan_amount(loanTypesDto.getLoan_amount())
                .repayment_period(loanTypesDto.getRepayment_period())
                .rate_of_interest(loanTypesDto.getRate_of_interest())
                .service_charge(loanTypesDto.getService_charge())
                .applicationDetails(loanTypesDto.getApplicationDetails())
                .build();
    }
}
