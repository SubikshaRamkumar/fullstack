package com.learn.springsecurity.mapper;

import com.learn.springsecurity.dto.response.dtos.RepaymentDetailDto;
import com.learn.springsecurity.model.RepaymentDetails;

public class RepaymentDetailsMapper {
    public static RepaymentDetailDto mapToRepaymentDetailDto(RepaymentDetails repaymentDetails)
    {
        return RepaymentDetailDto.builder()
                .repaymentId(repaymentDetails.getRepaymentId())
                .payment_date(repaymentDetails.getPayment_date())
                .amount_paid(repaymentDetails.getAmount_paid())
                .balance_amt(repaymentDetails.getBalance_amt())
                .total_amount(repaymentDetails.getTotal_amount())
                .paid_months(repaymentDetails.getPaid_months())
                .due_months(repaymentDetails.getDue_months())
                .applicationDetail(repaymentDetails.getApplicationDetail())
                .build();
    }
    public static RepaymentDetails mapToRepaymentDetails(RepaymentDetailDto repaymentDetailsDto)
    {
        return RepaymentDetails.builder()
                .repaymentId(repaymentDetailsDto.getRepaymentId())
                .payment_date(repaymentDetailsDto.getPayment_date())
                .amount_paid(repaymentDetailsDto.getAmount_paid())
                .balance_amt(repaymentDetailsDto.getBalance_amt())
                .total_amount(repaymentDetailsDto.getTotal_amount())
                .paid_months(repaymentDetailsDto.getPaid_months())
                .due_months(repaymentDetailsDto.getDue_months())
                .applicationDetail(repaymentDetailsDto.getApplicationDetail())
                .build();
    }
}
