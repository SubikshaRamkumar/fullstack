package com.learn.springsecurity.mapper;

import com.learn.springsecurity.dto.response.dtos.TransactionDto;
import com.learn.springsecurity.model.Transaction;

public class TransactionMapper {
    public static TransactionDto mapToTransactionDto(Transaction transaction)
    {
        return TransactionDto.builder()
                .transactionId(transaction.getTransactionId())
                .transaction_amount(transaction.getTransaction_amount())
                .transaction_date(transaction.getTransaction_date())
                .transaction_status(transaction.getTransaction_status())
                .applicationDetail(transaction.getApplicationDetail())
                .build();
    }
    public static Transaction mapToTransaction(TransactionDto transactionDto)
    {
        return Transaction.builder()
                .transactionId(transactionDto.getTransactionId())
                .transaction_amount(transactionDto.getTransaction_amount())
                .transaction_date(transactionDto.getTransaction_date())
                .transaction_status(transactionDto.getTransaction_status())
                .applicationDetail(transactionDto.getApplicationDetail())
                .build();
    }
}
