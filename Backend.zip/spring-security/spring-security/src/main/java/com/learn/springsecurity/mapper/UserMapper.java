package com.learn.springsecurity.mapper;

import com.learn.springsecurity.dto.response.dtos.UserDto;
import com.learn.springsecurity.model.User;

public class UserMapper {
    public static UserDto mapToUserDto(User user)
    {
        return UserDto.builder()
                .email(user.getEmail())
                .name(user.getName())
                .id(user.getId())
                .password(user.getPassword())
                .role(user.getRole())
                .age(user.getAge())
                .mobile_no(user.getMobile_no())
                .dateofBirth(user.getDateofBirth())
                .gender(user.getGender())
                .maritalStatus(user.getMaritalStatus())
                .addressLine1(user.getAddressLine1())
                .addressLine2(user.getAddressLine2())
                .city(user.getCity())
                .state(user.getState())
                .nationality(user.getNationality())
                .country(user.getCountry())
                .pincode(user.getPincode()).build();
    }
    public static User mapToUser(UserDto userDto)
    {
        return User.builder()
                .email(userDto.getEmail())
                .name(userDto.getName())
                .id(userDto.getId())
                .password(userDto.getPassword())
                .role(userDto.getRole())
                .age(userDto.getAge())
                .mobile_no(userDto.getMobile_no())
                .dateofBirth(userDto.getDateofBirth())
                .gender(userDto.getGender())
                .maritalStatus(userDto.getMaritalStatus())
                .addressLine1(userDto.getAddressLine1())
                .addressLine2(userDto.getAddressLine2())
                .city(userDto.getCity())
                .state(userDto.getState())
                .nationality(userDto.getNationality())
                .country(userDto.getCountry())
                .pincode(userDto.getPincode()).build();
    }
}
