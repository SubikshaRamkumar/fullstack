package com.learn.springsecurity.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

// import static jakarta.persistence.GenerationType.UUID;

import java.util.Set;

import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="_application_details")
public class ApplicationDetails {

    @Id
    // @GeneratedValue(strategy = UUID)
    // private String applicationId;

    @GeneratedValue(strategy = GenerationType.IDENTITY)    
    private Long applicationId;

    private String application_date;

    private String loan_amt_requested;

    private String tenure_in_months;
    
    private String application_status;

    private String approval_date;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId",nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "loanId", nullable = false)
    private LoanTypes loanType;

    @OneToOne(mappedBy = "applicationDetail", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = true) // by default optional is true. transaction happens only when admin approved so until then it is null. 
    private Transaction transaction;

    @OneToMany(mappedBy = "applicationDetail", cascade = CascadeType.ALL)
    private Set<RepaymentDetails> repayments;
}
