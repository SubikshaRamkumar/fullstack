package com.learn.springsecurity.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

// import static jakarta.persistence.GenerationType.UUID;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="_repayment_details")
public class RepaymentDetails {
    
    @Id
    // @GeneratedValue(strategy = UUID)
    // private String repaymentId;

    @GeneratedValue(strategy = GenerationType.IDENTITY)    
    private Long repaymentId;

    private String payment_date;

    private String amount_paid;

    private String balance_amt;

    private String total_amount;

    private String paid_months;

    private String due_months;

    @ManyToOne
    @JoinColumn(name = "applicationId", nullable = false)
    private ApplicationDetails applicationDetail;

}
