package com.learn.springsecurity.model;

// import static jakarta.persistence.GenerationType.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "_transaction_details")
public class Transaction {

    @Id
    // @GeneratedValue(strategy = UUID)
    // private String transactionId;

    @GeneratedValue(strategy = GenerationType.IDENTITY)    
    private Long transactionId;

    private String transaction_amount;

    private String transaction_date;

    private String transaction_status;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applicationId", nullable = false)
    private ApplicationDetails applicationDetail;
}
