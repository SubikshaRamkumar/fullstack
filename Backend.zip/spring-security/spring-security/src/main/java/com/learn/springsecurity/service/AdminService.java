package com.learn.springsecurity.service;

import java.util.List;

import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.dto.response.dtos.UserDto;

public interface AdminService {

    List<UserDto> getAllUserDetails();

    UserDto updateUserWithGivenId(Long userId, UserDto userDto);

    RegisterResponse deleteUser(Long userId);
}
