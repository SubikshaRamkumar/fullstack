package com.learn.springsecurity.service;

import java.security.Principal;

import com.learn.springsecurity.dto.request.PasswordRequest;
import com.learn.springsecurity.dto.response.dtos.UserDto;

public interface UserService {

    void forgotPassword(PasswordRequest request, Principal principal);

    UserDto getUserDetailsByEmail(String name);

    UserDto getUserDetailsById(Long userId);

    // List<UserDto> getAllUserDetails();

    // boolean isSelf(Principal principal, Long userId);

    //public boolean canAccessUserDetails(Long userId);

}
