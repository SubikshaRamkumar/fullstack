package com.learn.springsecurity.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.dto.response.dtos.UserDto;
import com.learn.springsecurity.exception.UserNotFoundException;
import com.learn.springsecurity.mapper.UserMapper;
import com.learn.springsecurity.model.User;
import com.learn.springsecurity.repository.UserRepository;
import com.learn.springsecurity.service.AdminService;
import org.springframework.transaction.annotation.Transactional;


import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;

    @Override
    public List<UserDto> getAllUserDetails() {
        List<User> users = userRepository.findAll();
        return users.stream()
                .map(user->UserDto.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .age(user.getAge())
                .role(user.getRole())
                .build())
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public UserDto updateUserWithGivenId(Long userId, UserDto userDto) {
        Optional<User> optionalUser = userRepository.findById(userId);
        User existingUser = optionalUser
        .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));
        // Update fields with values from UserDto
        System.out.println("existing User: "+existingUser.getName());
        // if (userDto.getName() != null) existingUser.setName(userDto.getName());
        // if (userDto.getEmail() != null) existingUser.setEmail(userDto.getEmail());
        System.out.println(userDto.getAge()+" age");
        if (userDto.getAge() != null) {existingUser.setAge(userDto.getAge());}
        // if (userDto.getMobile_no() != null) existingUser.setMobile_no(userDto.getMobile_no());
        // if (userDto.getDateofBirth() != null) existingUser.setDateofBirth(userDto.getDateofBirth());
        // if (userDto.getGender() != null) existingUser.setGender(userDto.getGender());
        // if (userDto.getMaritalStatus() != null) existingUser.setMaritalStatus(userDto.getMaritalStatus());
        // if (userDto.getAddressLine1() != null) existingUser.setAddressLine1(userDto.getAddressLine1());
        // if (userDto.getAddressLine2() != null) existingUser.setAddressLine2(userDto.getAddressLine2());
        // if (userDto.getCity() != null) existingUser.setCity(userDto.getCity());
        // if (userDto.getState() != null) existingUser.setState(userDto.getState());
        // if (userDto.getNationality() != null) existingUser.setNationality(userDto.getNationality());
        // if (userDto.getCountry() != null) existingUser.setCountry(userDto.getCountry());
        // if (userDto.getPincode() != null) existingUser.setPincode(userDto.getPincode());

        System.out.println("Before save: " + existingUser);

        // Save the updated entity back to the repository
        User updatedUser = userRepository.save(existingUser);
        userRepository.flush();
        System.out.println("After save: " + updatedUser);

        return UserMapper.mapToUserDto(updatedUser);


    }

     @Override
    public RegisterResponse deleteUser(Long userId) {
        userRepository.deleteById(userId);
        return RegisterResponse.builder().message("User Deleted Successfully").build();
    }
    
}
