package com.learn.springsecurity.service.impl;

import static com.learn.springsecurity.enumerated.TokenType.BEARER;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.learn.springsecurity.dto.request.LoginRequest;
import com.learn.springsecurity.dto.request.RegisterRequest;
import com.learn.springsecurity.dto.response.LoginResponse;
import com.learn.springsecurity.dto.response.RegisterResponse;
import com.learn.springsecurity.enumerated.Role;
import com.learn.springsecurity.model.Token;
import com.learn.springsecurity.model.User;
import com.learn.springsecurity.repository.TokenRepository;
import com.learn.springsecurity.repository.UserRepository;
import com.learn.springsecurity.service.AuthenticationService;
import com.learn.springsecurity.utils.JwtUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class AuthenticationServiceImpl implements AuthenticationService {

        private final PasswordEncoder passwordEncoder;
        private final AuthenticationManager authenticationManager;
        private final JwtUtil jwtUtil;  //Utility class for generating and validating JWT tokens.
        private final UserRepository userRepository;
        private final TokenRepository tokenRepository;

        @Override
        public RegisterResponse register(RegisterRequest request) {
                var user = User.builder()
                                .name(request.getName())
                                .email(request.getEmail())
                                .password(passwordEncoder.encode(request.getPassword()))
                                .role(Role.valueOf(request.getRole().toUpperCase()))
                                .build();
                userRepository.save(user);
                return RegisterResponse.builder()
                                .message("User registered successfully")
                                .build();
        }

        @Override
        public LoginResponse login(LoginRequest request) {
                authenticationManager
                                .authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(),
                                                request.getPassword()));  
                                                
                                                
                                                //creates a UsernamePasswordAuthenticationToken using the email and password provided in the LoginRequest object.
                                                //authenticate method of AuthenticationManager is then called with this token, effectively validating the user's credentials against the stored details (typically in a database).
               
               
                var user = userRepository.findByEmail(request.getEmail()).orElseThrow();


                Map<String, Object> claims = new HashMap<>();
                claims.put("role", user.getRole().toString());   //A HashMap named claims is created to hold the JWT claims. At least one claim, "role", is added to the map, representing the user's role.
// custom or private claim named "role" when generating a JWT token. 

                var accessToken = jwtUtil.generateToken(claims, user);

                revokeAllUserTokens(user);  //The revokeAllUserTokens(user) method is invoked to invalidate any existing tokens that have been issued to the user. This is a security measure to ensure that any previous tokens, potentially compromised, are no longer valid.

                saveUserToken(user, accessToken); //. This typically involves creating a new Token entity and persisting it.

                return LoginResponse.builder()
                                .message("Logged in successfully.")
                                .accessToken(accessToken)
                                .build();
        }

        private void saveUserToken(User user, String accessToken) {
                var token = Token.builder()
                                .user(user)
                                .token(accessToken)
                                .tokenType(BEARER)
                                .expired(false)
                                .revoked(false)
                                .build();
                tokenRepository.save(token);
        }

        private void revokeAllUserTokens(User user) {
                var validUserTokens = tokenRepository.findAllValidTokenByUser(user.getId());
                if (validUserTokens.isEmpty())
                        return;
                validUserTokens.forEach(token -> {
                        token.setExpired(true);
                        token.setRevoked(true);
                });
                tokenRepository.saveAll(validUserTokens);
        }

        @Override
        public void refreshToken(HttpServletRequest request, HttpServletResponse response) throws IOException {
                final String authHeader = request.getHeader(AUTHORIZATION);   //This header is expected to contain the refresh token, prefixed with "Bearer ".
                final String refreshToken;
                final String userEmail;


                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                        return;
                }


                refreshToken = authHeader.substring(7);  //Assuming the header is correctly formatted, it extracts the actual token part by removing the "Bearer " prefix.
                userEmail = jwtUtil.extractUsername(refreshToken);  // It uses jwtUtil.extractUsername(refreshToken) to extract the username (in this case, an email) from the refresh token. This is based on the assumption that the refresh token contains the username as a claim.

                if (userEmail != null) {
                        var user = this.userRepository.findByEmail(userEmail).orElseThrow();
                        if (jwtUtil.isTokenValid(refreshToken, user)) {
                                var accessToken = jwtUtil.generateToken(user);
                                revokeAllUserTokens(user);
                                saveUserToken(user, accessToken);
                                var authResponse = LoginResponse.builder()
                                                .message("New access token generated successfully.")
                                                .accessToken(accessToken)
                                                .build();
                                new ObjectMapper().writeValue(response.getOutputStream(), authResponse);  //This response object is serialized to JSON and written to the HttpServletResponse output stream, effectively returning the new access token to the client.
                        }
                }
        }

}
