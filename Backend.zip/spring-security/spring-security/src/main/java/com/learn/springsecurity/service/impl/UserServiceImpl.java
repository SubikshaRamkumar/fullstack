package com.learn.springsecurity.service.impl;

import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.security.core.Authentication;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.learn.springsecurity.dto.request.PasswordRequest;
import com.learn.springsecurity.dto.response.dtos.UserDto;
import com.learn.springsecurity.exception.UserNotFoundException;
import com.learn.springsecurity.mapper.UserMapper;
import com.learn.springsecurity.model.User;
import com.learn.springsecurity.repository.UserRepository;
import com.learn.springsecurity.service.UserService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    @Override
    public void forgotPassword(PasswordRequest request, Principal principal) {
        var user = (User) ((UsernamePasswordAuthenticationToken) principal).getPrincipal();

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword()))  //user.getPassword() is encoded and the other is raw that we got now that is the current password asked from the user for changing. 
            throw new IllegalStateException("Wrong password.");

        if (!request.getNewPassword().equals(request.getConfirmationPassword()))
            throw new IllegalStateException("Password mismatch.");

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
    }

    @Override
    public UserDto getUserDetailsByEmail(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        User user = optionalUser.orElseThrow(() ->
        new UserNotFoundException("User not found with email: " + email));
        return UserDto.builder()
        .id(user.getId())
        .name(user.getName())
        .email(user.getEmail())
        .password(user.getPassword())
        .age(user.getAge())
        .role(user.getRole())
        .build();
        // return UserMapper.mapToUserDto(user);
    }

    @Override
    public UserDto getUserDetailsById(Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        User user = optionalUser.orElseThrow(() ->
        new UserNotFoundException("User not found with id: " + userId));
        // return UserMapper.mapToUserDto(user);    
        return UserDto.builder()
        .id(user.getId())
        .name(user.getName())
        .email(user.getEmail())
        .password(user.getPassword())
        .age(user.getAge())
        .role(user.getRole())
        .build();
    }


    // @Override
    // public List<User> getAllUserDetails() {
    //     return userRepository.findAll();
    // }

    



    // @Override
    // public boolean isSelf(Principal principal, Long userId) {
    //     String email = principal.getName(); // Assuming the principal name is the user's email
    //     return userRepository.findByEmail(email)
    //             .map(User::getId)
    //             .filter(id -> id.equals(userId))
    //             .isPresent();
    // }

//     @Override
//     public boolean canAccessUserDetails(Long userId) {
//     Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//     String currentUsername = authentication.getName();
    
//     User currentUser = userRepository.findByEmail(currentUsername)
//                                      .orElseThrow(() -> new UsernameNotFoundException("User not found: " + currentUsername));
    
//     boolean hasUserIdMatch = currentUser.getId().equals(userId);
//     boolean hasAuthority = authentication.getAuthorities().stream()
//                                           .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("user:read"));
    
//     return hasUserIdMatch || hasAuthority;
// }

}
